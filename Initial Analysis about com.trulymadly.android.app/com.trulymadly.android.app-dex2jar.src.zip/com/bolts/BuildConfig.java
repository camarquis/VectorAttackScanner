package com.bolts;

public final class BuildConfig
{
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final String PACKAGE_NAME = "com.bolts";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "";
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.bolts.BuildConfig
 * JD-Core Version:    0.6.0
 */
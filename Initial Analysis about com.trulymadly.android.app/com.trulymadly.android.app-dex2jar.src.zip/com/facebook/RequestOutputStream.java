package com.facebook;

abstract interface RequestOutputStream
{
  public abstract void setCurrentRequest(Request paramRequest);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.facebook.RequestOutputStream
 * JD-Core Version:    0.6.0
 */
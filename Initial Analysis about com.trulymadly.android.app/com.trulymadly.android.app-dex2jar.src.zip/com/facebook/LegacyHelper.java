package com.facebook;

import android.os.Bundle;

public class LegacyHelper
{
  @Deprecated
  public static void extendTokenCompleted(Session paramSession, Bundle paramBundle)
  {
    paramSession.extendTokenCompleted(paramBundle);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.facebook.LegacyHelper
 * JD-Core Version:    0.6.0
 */
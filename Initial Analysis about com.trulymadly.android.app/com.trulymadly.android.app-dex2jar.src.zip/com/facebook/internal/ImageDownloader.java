package com.facebook.internal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import com.facebook.FacebookException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class ImageDownloader
{
  private static final int CACHE_READ_QUEUE_MAX_CONCURRENT = 2;
  private static final int DOWNLOAD_QUEUE_MAX_CONCURRENT = 8;
  private static WorkQueue cacheReadQueue;
  private static WorkQueue downloadQueue = new WorkQueue(8);
  private static Handler handler;
  private static final Map<RequestKey, DownloaderContext> pendingRequests;

  static
  {
    cacheReadQueue = new WorkQueue(2);
    pendingRequests = new HashMap();
  }

  public static boolean cancelRequest(ImageRequest paramImageRequest)
  {
    RequestKey localRequestKey = new RequestKey(paramImageRequest.getImageUri(), paramImageRequest.getCallerTag());
    synchronized (pendingRequests)
    {
      DownloaderContext localDownloaderContext = (DownloaderContext)pendingRequests.get(localRequestKey);
      int i = 0;
      if (localDownloaderContext != null)
      {
        i = 1;
        if (localDownloaderContext.workItem.cancel())
          pendingRequests.remove(localRequestKey);
      }
      else
      {
        return i;
      }
      localDownloaderContext.isCancelled = true;
    }
  }

  public static void clearCache(Context paramContext)
  {
    ImageResponseCache.clearCache(paramContext);
    UrlRedirectCache.clearCache(paramContext);
  }

  private static void download(RequestKey paramRequestKey, Context paramContext)
  {
    HttpURLConnection localHttpURLConnection = null;
    InputStream localInputStream = null;
    Bitmap localBitmap = null;
    int i = 1;
    try
    {
      localHttpURLConnection = (HttpURLConnection)new URL(paramRequestKey.uri.toString()).openConnection();
      localHttpURLConnection.setInstanceFollowRedirects(false);
      switch (localHttpURLConnection.getResponseCode())
      {
      default:
        localInputStream = localHttpURLConnection.getErrorStream();
        localInputStreamReader = new InputStreamReader(localInputStream);
        char[] arrayOfChar = new char[''];
        localStringBuilder = new StringBuilder();
        while (true)
        {
          int j = localInputStreamReader.read(arrayOfChar, 0, arrayOfChar.length);
          if (j <= 0)
            break;
          localStringBuilder.append(arrayOfChar, 0, j);
        }
      case 301:
      case 302:
      case 200:
      }
    }
    catch (IOException localIOException)
    {
      InputStreamReader localInputStreamReader;
      StringBuilder localStringBuilder;
      localObject2 = localIOException;
      Utility.closeQuietly(localInputStream);
      Utility.disconnectQuietly(localHttpURLConnection);
      if (i != 0)
        issueResponse(paramRequestKey, (Exception)localObject2, localBitmap, false);
      return;
      i = 0;
      String str = localHttpURLConnection.getHeaderField("location");
      boolean bool1 = Utility.isNullOrEmpty(str);
      localBitmap = null;
      localObject2 = null;
      i = 0;
      localInputStream = null;
      if (!bool1)
      {
        URI localURI = new URI(str);
        UrlRedirectCache.cacheUriRedirect(paramContext, paramRequestKey.uri, localURI);
        DownloaderContext localDownloaderContext = removePendingRequest(paramRequestKey);
        localBitmap = null;
        localObject2 = null;
        i = 0;
        localInputStream = null;
        if (localDownloaderContext != null)
        {
          boolean bool2 = localDownloaderContext.isCancelled;
          localBitmap = null;
          localObject2 = null;
          i = 0;
          localInputStream = null;
          if (!bool2)
          {
            ImageRequest localImageRequest = localDownloaderContext.request;
            RequestKey localRequestKey = new RequestKey(localURI, paramRequestKey.tag);
            enqueueCacheRead(localImageRequest, localRequestKey, false);
          }
        }
      }
      while (true)
      {
        Utility.closeQuietly(localInputStream);
        Utility.disconnectQuietly(localHttpURLConnection);
        break;
        localInputStream = ImageResponseCache.interceptAndCacheImageStream(paramContext, localHttpURLConnection);
        localBitmap = BitmapFactory.decodeStream(localInputStream);
        localObject2 = null;
        continue;
        Utility.closeQuietly(localInputStreamReader);
        localObject2 = new FacebookException(localStringBuilder.toString());
        localBitmap = null;
      }
    }
    catch (URISyntaxException localURISyntaxException)
    {
      while (true)
      {
        Object localObject2 = localURISyntaxException;
        Utility.closeQuietly(localInputStream);
        Utility.disconnectQuietly(localHttpURLConnection);
        localBitmap = null;
      }
    }
    finally
    {
      Utility.closeQuietly(localInputStream);
      Utility.disconnectQuietly(localHttpURLConnection);
    }
    throw localObject1;
  }

  public static void downloadAsync(ImageRequest paramImageRequest)
  {
    if (paramImageRequest == null)
      return;
    RequestKey localRequestKey = new RequestKey(paramImageRequest.getImageUri(), paramImageRequest.getCallerTag());
    while (true)
    {
      synchronized (pendingRequests)
      {
        DownloaderContext localDownloaderContext = (DownloaderContext)pendingRequests.get(localRequestKey);
        if (localDownloaderContext != null)
        {
          localDownloaderContext.request = paramImageRequest;
          localDownloaderContext.isCancelled = false;
          localDownloaderContext.workItem.moveToFront();
          return;
        }
      }
      enqueueCacheRead(paramImageRequest, localRequestKey, paramImageRequest.isCachedRedirectAllowed());
    }
  }

  private static void enqueueCacheRead(ImageRequest paramImageRequest, RequestKey paramRequestKey, boolean paramBoolean)
  {
    enqueueRequest(paramImageRequest, paramRequestKey, cacheReadQueue, new CacheReadWorkItem(paramImageRequest.getContext(), paramRequestKey, paramBoolean));
  }

  private static void enqueueDownload(ImageRequest paramImageRequest, RequestKey paramRequestKey)
  {
    enqueueRequest(paramImageRequest, paramRequestKey, downloadQueue, new DownloadImageWorkItem(paramImageRequest.getContext(), paramRequestKey));
  }

  private static void enqueueRequest(ImageRequest paramImageRequest, RequestKey paramRequestKey, WorkQueue paramWorkQueue, Runnable paramRunnable)
  {
    synchronized (pendingRequests)
    {
      DownloaderContext localDownloaderContext = new DownloaderContext(null);
      localDownloaderContext.request = paramImageRequest;
      pendingRequests.put(paramRequestKey, localDownloaderContext);
      localDownloaderContext.workItem = paramWorkQueue.addActiveWorkItem(paramRunnable);
      return;
    }
  }

  private static Handler getHandler()
  {
    monitorenter;
    try
    {
      if (handler == null)
        handler = new Handler(Looper.getMainLooper());
      Handler localHandler = handler;
      return localHandler;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  private static void issueResponse(RequestKey paramRequestKey, Exception paramException, Bitmap paramBitmap, boolean paramBoolean)
  {
    DownloaderContext localDownloaderContext = removePendingRequest(paramRequestKey);
    if ((localDownloaderContext != null) && (!localDownloaderContext.isCancelled))
    {
      ImageRequest localImageRequest = localDownloaderContext.request;
      ImageRequest.Callback localCallback = localImageRequest.getCallback();
      if (localCallback != null)
        getHandler().post(new Runnable(localImageRequest, paramException, paramBoolean, paramBitmap, localCallback)
        {
          public void run()
          {
            ImageResponse localImageResponse = new ImageResponse(this.val$request, this.val$error, this.val$isCachedRedirect, this.val$bitmap);
            this.val$callback.onCompleted(localImageResponse);
          }
        });
    }
  }

  public static void prioritizeRequest(ImageRequest paramImageRequest)
  {
    RequestKey localRequestKey = new RequestKey(paramImageRequest.getImageUri(), paramImageRequest.getCallerTag());
    synchronized (pendingRequests)
    {
      DownloaderContext localDownloaderContext = (DownloaderContext)pendingRequests.get(localRequestKey);
      if (localDownloaderContext != null)
        localDownloaderContext.workItem.moveToFront();
      return;
    }
  }

  private static void readFromCache(RequestKey paramRequestKey, Context paramContext, boolean paramBoolean)
  {
    InputStream localInputStream = null;
    boolean bool = false;
    if (paramBoolean)
    {
      URI localURI = UrlRedirectCache.getRedirectedUri(paramContext, paramRequestKey.uri);
      localInputStream = null;
      bool = false;
      if (localURI != null)
      {
        localInputStream = ImageResponseCache.getCachedImageStream(localURI, paramContext);
        if (localInputStream == null)
          break label81;
        bool = true;
      }
    }
    if (!bool)
      localInputStream = ImageResponseCache.getCachedImageStream(paramRequestKey.uri, paramContext);
    if (localInputStream != null)
    {
      Bitmap localBitmap = BitmapFactory.decodeStream(localInputStream);
      Utility.closeQuietly(localInputStream);
      issueResponse(paramRequestKey, null, localBitmap, bool);
    }
    label81: DownloaderContext localDownloaderContext;
    do
    {
      return;
      bool = false;
      break;
      localDownloaderContext = removePendingRequest(paramRequestKey);
    }
    while ((localDownloaderContext == null) || (localDownloaderContext.isCancelled));
    enqueueDownload(localDownloaderContext.request, paramRequestKey);
  }

  private static DownloaderContext removePendingRequest(RequestKey paramRequestKey)
  {
    synchronized (pendingRequests)
    {
      DownloaderContext localDownloaderContext = (DownloaderContext)pendingRequests.remove(paramRequestKey);
      return localDownloaderContext;
    }
  }

  private static class CacheReadWorkItem
    implements Runnable
  {
    private boolean allowCachedRedirects;
    private Context context;
    private ImageDownloader.RequestKey key;

    CacheReadWorkItem(Context paramContext, ImageDownloader.RequestKey paramRequestKey, boolean paramBoolean)
    {
      this.context = paramContext;
      this.key = paramRequestKey;
      this.allowCachedRedirects = paramBoolean;
    }

    public void run()
    {
      ImageDownloader.access$100(this.key, this.context, this.allowCachedRedirects);
    }
  }

  private static class DownloadImageWorkItem
    implements Runnable
  {
    private Context context;
    private ImageDownloader.RequestKey key;

    DownloadImageWorkItem(Context paramContext, ImageDownloader.RequestKey paramRequestKey)
    {
      this.context = paramContext;
      this.key = paramRequestKey;
    }

    public void run()
    {
      ImageDownloader.access$200(this.key, this.context);
    }
  }

  private static class DownloaderContext
  {
    boolean isCancelled;
    ImageRequest request;
    WorkQueue.WorkItem workItem;
  }

  private static class RequestKey
  {
    private static final int HASH_MULTIPLIER = 37;
    private static final int HASH_SEED = 29;
    Object tag;
    URI uri;

    RequestKey(URI paramURI, Object paramObject)
    {
      this.uri = paramURI;
      this.tag = paramObject;
    }

    public boolean equals(Object paramObject)
    {
      int i = 0;
      if (paramObject != null)
      {
        boolean bool = paramObject instanceof RequestKey;
        i = 0;
        if (bool)
        {
          RequestKey localRequestKey = (RequestKey)paramObject;
          if ((localRequestKey.uri != this.uri) || (localRequestKey.tag != this.tag))
            break label51;
          i = 1;
        }
      }
      return i;
      label51: return false;
    }

    public int hashCode()
    {
      return 37 * (1073 + this.uri.hashCode()) + this.tag.hashCode();
    }
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.facebook.internal.ImageDownloader
 * JD-Core Version:    0.6.0
 */
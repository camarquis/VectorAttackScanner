package com.facebook.internal;

interface package-info
{
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.facebook.internal.package-info
 * JD-Core Version:    0.6.0
 */
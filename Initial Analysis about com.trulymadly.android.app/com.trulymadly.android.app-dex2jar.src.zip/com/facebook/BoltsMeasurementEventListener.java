package com.facebook;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;

public class BoltsMeasurementEventListener extends BroadcastReceiver
{
  private static final String BOLTS_MEASUREMENT_EVENT_PREFIX = "bf_";
  private static final String MEASUREMENT_EVENT_ARGS_KEY = "event_args";
  private static final String MEASUREMENT_EVENT_NAME_KEY = "event_name";
  private static final String MEASUREMENT_EVENT_NOTIFICATION_NAME = "com.parse.bolts.measurement_event";
  private static BoltsMeasurementEventListener _instance;
  private Context applicationContext;

  private BoltsMeasurementEventListener(Context paramContext)
  {
    this.applicationContext = paramContext.getApplicationContext();
  }

  private void close()
  {
    LocalBroadcastManager.getInstance(this.applicationContext).unregisterReceiver(this);
  }

  static BoltsMeasurementEventListener getInstance(Context paramContext)
  {
    if (_instance != null)
      return _instance;
    _instance = new BoltsMeasurementEventListener(paramContext);
    _instance.open();
    return _instance;
  }

  private void open()
  {
    LocalBroadcastManager.getInstance(this.applicationContext).registerReceiver(this, new IntentFilter("com.parse.bolts.measurement_event"));
  }

  protected void finalize()
    throws Throwable
  {
    try
    {
      close();
      return;
    }
    finally
    {
      super.finalize();
    }
    throw localObject;
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    AppEventsLogger.newLogger(paramContext).logEvent("bf_" + paramIntent.getStringExtra("event_name"), paramIntent.getBundleExtra("event_args"));
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.facebook.BoltsMeasurementEventListener
 * JD-Core Version:    0.6.0
 */
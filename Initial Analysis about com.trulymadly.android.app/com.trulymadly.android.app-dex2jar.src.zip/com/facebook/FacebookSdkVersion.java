package com.facebook;

final class FacebookSdkVersion
{
  public static final String BUILD = "3.17.0";
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.facebook.FacebookSdkVersion
 * JD-Core Version:    0.6.0
 */
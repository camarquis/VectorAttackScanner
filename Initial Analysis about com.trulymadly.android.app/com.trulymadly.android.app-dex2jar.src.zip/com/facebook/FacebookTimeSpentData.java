package com.facebook;

import android.os.Bundle;
import com.facebook.internal.Logger;
import java.io.Serializable;

class FacebookTimeSpentData
  implements Serializable
{
  private static final long APP_ACTIVATE_SUPPRESSION_PERIOD_IN_MILLISECONDS = 300000L;
  private static final long FIRST_TIME_LOAD_RESUME_TIME = -1L;
  private static final long[] INACTIVE_SECONDS_QUANTA;
  private static final long INTERRUPTION_THRESHOLD_MILLISECONDS = 1000L;
  private static final long NUM_MILLISECONDS_IDLE_TO_BE_NEW_SESSION = 60000L;
  private static final String TAG = AppEventsLogger.class.getCanonicalName();
  private static final long serialVersionUID = 1L;
  private int interruptionCount;
  private boolean isAppActive;
  private long lastResumeTime;
  private long lastSuspendTime;
  private long millisecondsSpentInSession;

  static
  {
    INACTIVE_SECONDS_QUANTA = new long[] { 300000L, 900000L, 1800000L, 3600000L, 21600000L, 43200000L, 86400000L, 172800000L, 259200000L, 604800000L, 1209600000L, 1814400000L, 2419200000L, 5184000000L, 7776000000L, 10368000000L, 12960000000L, 15552000000L, 31536000000L };
  }

  FacebookTimeSpentData()
  {
    resetSession();
  }

  private FacebookTimeSpentData(long paramLong1, long paramLong2, long paramLong3, int paramInt)
  {
    resetSession();
    this.lastResumeTime = paramLong1;
    this.lastSuspendTime = paramLong2;
    this.millisecondsSpentInSession = paramLong3;
    this.interruptionCount = paramInt;
  }

  private static int getQuantaIndex(long paramLong)
  {
    for (int i = 0; (i < INACTIVE_SECONDS_QUANTA.length) && (INACTIVE_SECONDS_QUANTA[i] < paramLong); i++);
    return i;
  }

  private boolean isNewActivation()
  {
    return this.lastResumeTime == -1L;
  }

  private void logAppDeactivatedEvent(AppEventsLogger paramAppEventsLogger, long paramLong)
  {
    Bundle localBundle = new Bundle();
    localBundle.putInt("fb_mobile_app_interruptions", this.interruptionCount);
    localBundle.putInt("fb_mobile_time_between_sessions", getQuantaIndex(paramLong));
    paramAppEventsLogger.logEvent("fb_mobile_deactivate_app", this.millisecondsSpentInSession / 1000L, localBundle);
    resetSession();
  }

  private void resetSession()
  {
    this.isAppActive = false;
    this.lastResumeTime = -1L;
    this.lastSuspendTime = -1L;
    this.interruptionCount = 0;
    this.millisecondsSpentInSession = 0L;
  }

  private Object writeReplace()
  {
    return new SerializationProxyV1(this.lastResumeTime, this.lastSuspendTime, this.millisecondsSpentInSession, this.interruptionCount);
  }

  void onResume(AppEventsLogger paramAppEventsLogger, long paramLong)
  {
    if (this.isAppActive)
    {
      Logger.log(LoggingBehavior.APP_EVENTS, TAG, "Resume for active app");
      return;
    }
    long l;
    if (isNewActivation())
    {
      l = 0L;
      if (l < 0L)
      {
        Logger.log(LoggingBehavior.APP_EVENTS, TAG, "Clock skew detected");
        l = 0L;
      }
      if ((isNewActivation()) || (paramLong - this.lastResumeTime > 300000L))
        paramAppEventsLogger.logEvent("fb_mobile_activate_app");
      if (l <= 60000L)
        break label114;
      logAppDeactivatedEvent(paramAppEventsLogger, l);
    }
    while (true)
    {
      this.lastResumeTime = paramLong;
      this.isAppActive = true;
      return;
      l = paramLong - this.lastSuspendTime;
      break;
      label114: if (l <= 1000L)
        continue;
      this.interruptionCount = (1 + this.interruptionCount);
    }
  }

  void onSuspend(AppEventsLogger paramAppEventsLogger, long paramLong)
  {
    if (!this.isAppActive)
    {
      Logger.log(LoggingBehavior.APP_EVENTS, TAG, "Suspend for inactive app");
      return;
    }
    long l = paramLong - this.lastResumeTime;
    if (l < 0L)
    {
      Logger.log(LoggingBehavior.APP_EVENTS, TAG, "Clock skew detected");
      l = 0L;
    }
    this.millisecondsSpentInSession = (l + this.millisecondsSpentInSession);
    this.lastSuspendTime = paramLong;
    this.isAppActive = false;
  }

  private static class SerializationProxyV1
    implements Serializable
  {
    private static final long serialVersionUID = 6L;
    private final int interruptionCount;
    private final long lastResumeTime;
    private final long lastSuspendTime;
    private final long millisecondsSpentInSession;

    SerializationProxyV1(long paramLong1, long paramLong2, long paramLong3, int paramInt)
    {
      this.lastResumeTime = paramLong1;
      this.lastSuspendTime = paramLong2;
      this.millisecondsSpentInSession = paramLong3;
      this.interruptionCount = paramInt;
    }

    private Object readResolve()
    {
      return new FacebookTimeSpentData(this.lastResumeTime, this.lastSuspendTime, this.millisecondsSpentInSession, this.interruptionCount, null);
    }
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.facebook.FacebookTimeSpentData
 * JD-Core Version:    0.6.0
 */
package com.facebook.android;

public final class R
{
  public static final class attr
  {
    public static final int confirm_logout = 2130772121;
    public static final int done_button_background = 2130772115;
    public static final int done_button_text = 2130772113;
    public static final int extra_fields = 2130772110;
    public static final int fetch_user_info = 2130772122;
    public static final int is_cropped = 2130772126;
    public static final int login_text = 2130772123;
    public static final int logout_text = 2130772124;
    public static final int multi_select = 2130772116;
    public static final int preset_size = 2130772125;
    public static final int radius_in_meters = 2130772117;
    public static final int results_limit = 2130772118;
    public static final int search_text = 2130772119;
    public static final int show_pictures = 2130772109;
    public static final int show_search_box = 2130772120;
    public static final int show_title_bar = 2130772111;
    public static final int title_bar_background = 2130772114;
    public static final int title_text = 2130772112;
  }

  public static final class color
  {
    public static final int com_facebook_blue = 2131165199;
    public static final int com_facebook_loginview_text_color = 2131165203;
    public static final int com_facebook_picker_search_bar_background = 2131165197;
    public static final int com_facebook_picker_search_bar_text = 2131165198;
    public static final int com_facebook_usersettingsfragment_connected_shadow_color = 2131165201;
    public static final int com_facebook_usersettingsfragment_connected_text_color = 2131165200;
    public static final int com_facebook_usersettingsfragment_not_connected_text_color = 2131165202;
  }

  public static final class dimen
  {
    public static final int com_facebook_loginview_compound_drawable_padding = 2131230749;
    public static final int com_facebook_loginview_padding_bottom = 2131230748;
    public static final int com_facebook_loginview_padding_left = 2131230745;
    public static final int com_facebook_loginview_padding_right = 2131230746;
    public static final int com_facebook_loginview_padding_top = 2131230747;
    public static final int com_facebook_loginview_text_size = 2131230750;
    public static final int com_facebook_picker_divider_width = 2131230742;
    public static final int com_facebook_picker_place_image_size = 2131230741;
    public static final int com_facebook_profilepictureview_preset_size_large = 2131230753;
    public static final int com_facebook_profilepictureview_preset_size_normal = 2131230752;
    public static final int com_facebook_profilepictureview_preset_size_small = 2131230751;
    public static final int com_facebook_tooltip_horizontal_padding = 2131230754;
    public static final int com_facebook_usersettingsfragment_profile_picture_height = 2131230744;
    public static final int com_facebook_usersettingsfragment_profile_picture_width = 2131230743;
  }

  public static final class drawable
  {
    public static final int com_facebook_button_blue = 2130837612;
    public static final int com_facebook_button_blue_focused = 2130837613;
    public static final int com_facebook_button_blue_normal = 2130837614;
    public static final int com_facebook_button_blue_pressed = 2130837615;
    public static final int com_facebook_button_check = 2130837616;
    public static final int com_facebook_button_check_off = 2130837617;
    public static final int com_facebook_button_check_on = 2130837618;
    public static final int com_facebook_button_grey_focused = 2130837619;
    public static final int com_facebook_button_grey_normal = 2130837620;
    public static final int com_facebook_button_grey_pressed = 2130837621;
    public static final int com_facebook_close = 2130837622;
    public static final int com_facebook_inverse_icon = 2130837623;
    public static final int com_facebook_list_divider = 2130837624;
    public static final int com_facebook_list_section_header_background = 2130837625;
    public static final int com_facebook_loginbutton_silver = 2130837626;
    public static final int com_facebook_logo = 2130837627;
    public static final int com_facebook_picker_default_separator_color = 2130837876;
    public static final int com_facebook_picker_item_background = 2130837628;
    public static final int com_facebook_picker_list_focused = 2130837629;
    public static final int com_facebook_picker_list_longpressed = 2130837630;
    public static final int com_facebook_picker_list_pressed = 2130837631;
    public static final int com_facebook_picker_list_selector = 2130837632;
    public static final int com_facebook_picker_list_selector_background_transition = 2130837633;
    public static final int com_facebook_picker_list_selector_disabled = 2130837634;
    public static final int com_facebook_picker_magnifier = 2130837635;
    public static final int com_facebook_picker_top_button = 2130837636;
    public static final int com_facebook_place_default_icon = 2130837637;
    public static final int com_facebook_profile_default_icon = 2130837638;
    public static final int com_facebook_profile_picture_blank_portrait = 2130837639;
    public static final int com_facebook_profile_picture_blank_square = 2130837640;
    public static final int com_facebook_tooltip_black_background = 2130837641;
    public static final int com_facebook_tooltip_black_bottomnub = 2130837642;
    public static final int com_facebook_tooltip_black_topnub = 2130837643;
    public static final int com_facebook_tooltip_black_xout = 2130837644;
    public static final int com_facebook_tooltip_blue_background = 2130837645;
    public static final int com_facebook_tooltip_blue_bottomnub = 2130837646;
    public static final int com_facebook_tooltip_blue_topnub = 2130837647;
    public static final int com_facebook_tooltip_blue_xout = 2130837648;
    public static final int com_facebook_top_background = 2130837649;
    public static final int com_facebook_top_button = 2130837650;
    public static final int com_facebook_usersettingsfragment_background_gradient = 2130837651;
  }

  public static final class id
  {
    public static final int com_facebook_body_frame = 2131361914;
    public static final int com_facebook_button_xout = 2131361916;
    public static final int com_facebook_login_activity_progress_bar = 2131361898;
    public static final int com_facebook_picker_activity_circle = 2131361897;
    public static final int com_facebook_picker_checkbox = 2131361900;
    public static final int com_facebook_picker_checkbox_stub = 2131361904;
    public static final int com_facebook_picker_divider = 2131361908;
    public static final int com_facebook_picker_done_button = 2131361907;
    public static final int com_facebook_picker_image = 2131361901;
    public static final int com_facebook_picker_list_section_header = 2131361905;
    public static final int com_facebook_picker_list_view = 2131361896;
    public static final int com_facebook_picker_profile_pic_stub = 2131361902;
    public static final int com_facebook_picker_row_activity_circle = 2131361899;
    public static final int com_facebook_picker_search_text = 2131361913;
    public static final int com_facebook_picker_title = 2131361903;
    public static final int com_facebook_picker_title_bar = 2131361910;
    public static final int com_facebook_picker_title_bar_stub = 2131361909;
    public static final int com_facebook_picker_top_bar = 2131361906;
    public static final int com_facebook_search_bar_view = 2131361912;
    public static final int com_facebook_tooltip_bubble_view_bottom_pointer = 2131361918;
    public static final int com_facebook_tooltip_bubble_view_text_body = 2131361917;
    public static final int com_facebook_tooltip_bubble_view_top_pointer = 2131361915;
    public static final int com_facebook_usersettingsfragment_login_button = 2131361921;
    public static final int com_facebook_usersettingsfragment_logo_image = 2131361919;
    public static final int com_facebook_usersettingsfragment_profile_name = 2131361920;
    public static final int large = 2131361826;
    public static final int normal = 2131361800;
    public static final int picker_subtitle = 2131361911;
    public static final int small = 2131361827;
  }

  public static final class layout
  {
    public static final int com_facebook_friendpickerfragment = 2130903069;
    public static final int com_facebook_login_activity_layout = 2130903070;
    public static final int com_facebook_picker_activity_circle_row = 2130903071;
    public static final int com_facebook_picker_checkbox = 2130903072;
    public static final int com_facebook_picker_image = 2130903073;
    public static final int com_facebook_picker_list_row = 2130903074;
    public static final int com_facebook_picker_list_section_header = 2130903075;
    public static final int com_facebook_picker_search_box = 2130903076;
    public static final int com_facebook_picker_title_bar = 2130903077;
    public static final int com_facebook_picker_title_bar_stub = 2130903078;
    public static final int com_facebook_placepickerfragment = 2130903079;
    public static final int com_facebook_placepickerfragment_list_row = 2130903080;
    public static final int com_facebook_search_bar_layout = 2130903081;
    public static final int com_facebook_tooltip_bubble = 2130903082;
    public static final int com_facebook_usersettingsfragment = 2130903083;
  }

  public static final class string
  {
    public static final int com_facebook_choose_friends = 2131427383;
    public static final int com_facebook_dialogloginactivity_ok_button = 2131427368;
    public static final int com_facebook_internet_permission_error_message = 2131427387;
    public static final int com_facebook_internet_permission_error_title = 2131427386;
    public static final int com_facebook_loading = 2131427385;
    public static final int com_facebook_loginview_cancel_action = 2131427374;
    public static final int com_facebook_loginview_log_in_button = 2131427370;
    public static final int com_facebook_loginview_log_out_action = 2131427373;
    public static final int com_facebook_loginview_log_out_button = 2131427369;
    public static final int com_facebook_loginview_logged_in_as = 2131427371;
    public static final int com_facebook_loginview_logged_in_using_facebook = 2131427372;
    public static final int com_facebook_logo_content_description = 2131427375;
    public static final int com_facebook_nearby = 2131427384;
    public static final int com_facebook_picker_done_button_text = 2131427382;
    public static final int com_facebook_placepicker_subtitle_catetory_only_format = 2131427380;
    public static final int com_facebook_placepicker_subtitle_format = 2131427379;
    public static final int com_facebook_placepicker_subtitle_were_here_only_format = 2131427381;
    public static final int com_facebook_requesterror_password_changed = 2131427390;
    public static final int com_facebook_requesterror_permissions = 2131427392;
    public static final int com_facebook_requesterror_reconnect = 2131427391;
    public static final int com_facebook_requesterror_relogin = 2131427389;
    public static final int com_facebook_requesterror_web_login = 2131427388;
    public static final int com_facebook_tooltip_default = 2131427393;
    public static final int com_facebook_usersettingsfragment_log_in_button = 2131427376;
    public static final int com_facebook_usersettingsfragment_logged_in = 2131427377;
    public static final int com_facebook_usersettingsfragment_not_logged_in = 2131427378;
  }

  public static final class style
  {
    public static final int com_facebook_loginview_default_style = 2131493003;
    public static final int com_facebook_loginview_silver_style = 2131493004;
    public static final int tooltip_bubble_text = 2131493005;
  }

  public static final class styleable
  {
    public static final int[] com_facebook_friend_picker_fragment = { 2130772116 };
    public static final int com_facebook_friend_picker_fragment_multi_select = 0;
    public static final int[] com_facebook_login_view = { 2130772121, 2130772122, 2130772123, 2130772124 };
    public static final int com_facebook_login_view_confirm_logout = 0;
    public static final int com_facebook_login_view_fetch_user_info = 1;
    public static final int com_facebook_login_view_login_text = 2;
    public static final int com_facebook_login_view_logout_text = 3;
    public static final int[] com_facebook_picker_fragment = { 2130772109, 2130772110, 2130772111, 2130772112, 2130772113, 2130772114, 2130772115 };
    public static final int com_facebook_picker_fragment_done_button_background = 6;
    public static final int com_facebook_picker_fragment_done_button_text = 4;
    public static final int com_facebook_picker_fragment_extra_fields = 1;
    public static final int com_facebook_picker_fragment_show_pictures = 0;
    public static final int com_facebook_picker_fragment_show_title_bar = 2;
    public static final int com_facebook_picker_fragment_title_bar_background = 5;
    public static final int com_facebook_picker_fragment_title_text = 3;
    public static final int[] com_facebook_place_picker_fragment = { 2130772117, 2130772118, 2130772119, 2130772120 };
    public static final int com_facebook_place_picker_fragment_radius_in_meters = 0;
    public static final int com_facebook_place_picker_fragment_results_limit = 1;
    public static final int com_facebook_place_picker_fragment_search_text = 2;
    public static final int com_facebook_place_picker_fragment_show_search_box = 3;
    public static final int[] com_facebook_profile_picture_view = { 2130772125, 2130772126 };
    public static final int com_facebook_profile_picture_view_is_cropped = 1;
    public static final int com_facebook_profile_picture_view_preset_size;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.facebook.android.R
 * JD-Core Version:    0.6.0
 */
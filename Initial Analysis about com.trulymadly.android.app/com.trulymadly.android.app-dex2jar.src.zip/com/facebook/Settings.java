package com.facebook;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.facebook.internal.AttributionIdentifiers;
import com.facebook.internal.Utility;
import com.facebook.internal.Utility.FetchedAppSettings;
import com.facebook.internal.Validate;
import com.facebook.model.GraphObject;
import com.facebook.model.GraphObject.Factory;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import org.json.JSONException;
import org.json.JSONObject;

public final class Settings
{
  private static final String ANALYTICS_EVENT = "event";
  public static final String APPLICATION_ID_PROPERTY = "com.facebook.sdk.ApplicationId";
  private static final String APP_EVENT_PREFERENCES = "com.facebook.sdk.appEventPreferences";
  private static final String ATTRIBUTION_ID_COLUMN_NAME = "aid";
  private static final Uri ATTRIBUTION_ID_CONTENT_URI;
  private static final String ATTRIBUTION_PREFERENCES = "com.facebook.sdk.attributionTracking";
  private static final String AUTO_PUBLISH = "auto_publish";
  public static final String CLIENT_TOKEN_PROPERTY = "com.facebook.sdk.ClientToken";
  private static final int DEFAULT_CORE_POOL_SIZE = 5;
  private static final int DEFAULT_KEEP_ALIVE = 1;
  private static final int DEFAULT_MAXIMUM_POOL_SIZE = 128;
  private static final ThreadFactory DEFAULT_THREAD_FACTORY;
  private static final BlockingQueue<Runnable> DEFAULT_WORK_QUEUE;
  private static final String FACEBOOK_COM = "facebook.com";
  private static final Object LOCK;
  private static final String MOBILE_INSTALL_EVENT = "MOBILE_APP_INSTALL";
  private static final String PUBLISH_ACTIVITY_PATH = "%s/activities";
  private static final String TAG = Settings.class.getCanonicalName();
  private static volatile String appClientToken;
  private static volatile String appVersion;
  private static volatile String applicationId;
  private static volatile boolean defaultsLoaded;
  private static volatile Executor executor;
  private static volatile String facebookDomain;
  private static volatile boolean isLoggingEnabled;
  private static final HashSet<LoggingBehavior> loggingBehaviors;
  private static AtomicLong onProgressThreshold;
  private static volatile boolean platformCompatibilityEnabled;
  private static Boolean sdkInitialized;
  private static volatile boolean shouldAutoPublishInstall;

  static
  {
    LoggingBehavior[] arrayOfLoggingBehavior = new LoggingBehavior[1];
    arrayOfLoggingBehavior[0] = LoggingBehavior.DEVELOPER_ERRORS;
    loggingBehaviors = new HashSet(Arrays.asList(arrayOfLoggingBehavior));
    defaultsLoaded = false;
    facebookDomain = "facebook.com";
    onProgressThreshold = new AtomicLong(65536L);
    isLoggingEnabled = false;
    LOCK = new Object();
    ATTRIBUTION_ID_CONTENT_URI = Uri.parse("content://com.facebook.katana.provider.AttributionIdProvider");
    DEFAULT_WORK_QUEUE = new LinkedBlockingQueue(10);
    DEFAULT_THREAD_FACTORY = new ThreadFactory()
    {
      private final AtomicInteger counter = new AtomicInteger(0);

      public Thread newThread(Runnable paramRunnable)
      {
        return new Thread(paramRunnable, "FacebookSdk #" + this.counter.incrementAndGet());
      }
    };
    sdkInitialized = Boolean.valueOf(false);
  }

  public static final void addLoggingBehavior(LoggingBehavior paramLoggingBehavior)
  {
    synchronized (loggingBehaviors)
    {
      loggingBehaviors.add(paramLoggingBehavior);
      return;
    }
  }

  public static final void clearLoggingBehaviors()
  {
    synchronized (loggingBehaviors)
    {
      loggingBehaviors.clear();
      return;
    }
  }

  public static String getAppVersion()
  {
    return appVersion;
  }

  public static String getApplicationId()
  {
    return applicationId;
  }

  // ERROR //
  private static Executor getAsyncTaskExecutor()
  {
    // Byte code:
    //   0: ldc 173
    //   2: ldc 175
    //   4: invokevirtual 179	java/lang/Class:getField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   7: astore_1
    //   8: aload_1
    //   9: aconst_null
    //   10: invokevirtual 185	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   13: astore_3
    //   14: aload_3
    //   15: ifnonnull +11 -> 26
    //   18: aconst_null
    //   19: areturn
    //   20: astore_0
    //   21: aconst_null
    //   22: areturn
    //   23: astore_2
    //   24: aconst_null
    //   25: areturn
    //   26: aload_3
    //   27: instanceof 187
    //   30: ifne +5 -> 35
    //   33: aconst_null
    //   34: areturn
    //   35: aload_3
    //   36: checkcast 187	java/util/concurrent/Executor
    //   39: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	8	20	java/lang/NoSuchFieldException
    //   8	14	23	java/lang/IllegalAccessException
  }

  public static String getAttributionId(ContentResolver paramContentResolver)
  {
    try
    {
      String[] arrayOfString = { "aid" };
      Cursor localCursor = paramContentResolver.query(ATTRIBUTION_ID_CONTENT_URI, arrayOfString, null, null, null);
      if ((localCursor != null) && (localCursor.moveToFirst()))
      {
        String str = localCursor.getString(localCursor.getColumnIndex("aid"));
        localCursor.close();
        return str;
      }
    }
    catch (Exception localException)
    {
      Log.d(TAG, "Caught unexpected exception in getAttributionId(): " + localException.toString());
      return null;
    }
    return null;
  }

  public static String getClientToken()
  {
    return appClientToken;
  }

  public static Executor getExecutor()
  {
    synchronized (LOCK)
    {
      if (executor == null)
      {
        Object localObject3 = getAsyncTaskExecutor();
        if (localObject3 == null)
          localObject3 = new ThreadPoolExecutor(5, 128, 1L, TimeUnit.SECONDS, DEFAULT_WORK_QUEUE, DEFAULT_THREAD_FACTORY);
        executor = (Executor)localObject3;
      }
      return executor;
    }
  }

  public static String getFacebookDomain()
  {
    return facebookDomain;
  }

  public static boolean getLimitEventAndDataUsage(Context paramContext)
  {
    return paramContext.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).getBoolean("limitEventUsage", false);
  }

  public static final Set<LoggingBehavior> getLoggingBehaviors()
  {
    synchronized (loggingBehaviors)
    {
      Set localSet = Collections.unmodifiableSet(new HashSet(loggingBehaviors));
      return localSet;
    }
  }

  public static long getOnProgressThreshold()
  {
    return onProgressThreshold.get();
  }

  public static boolean getPlatformCompatibilityEnabled()
  {
    return platformCompatibilityEnabled;
  }

  public static String getSdkVersion()
  {
    return "3.17.0";
  }

  @Deprecated
  public static boolean getShouldAutoPublishInstall()
  {
    return shouldAutoPublishInstall;
  }

  public static final boolean isLoggingBehaviorEnabled(LoggingBehavior paramLoggingBehavior)
  {
    while (true)
    {
      synchronized (loggingBehaviors)
      {
        if ((isLoggingEnabled()) && (loggingBehaviors.contains(paramLoggingBehavior)))
        {
          i = 1;
          return i;
        }
      }
      int i = 0;
    }
  }

  public static final boolean isLoggingEnabled()
  {
    return isLoggingEnabled;
  }

  public static void loadDefaultsFromMetadata(Context paramContext)
  {
    defaultsLoaded = true;
    if (paramContext == null);
    while (true)
    {
      return;
      try
      {
        ApplicationInfo localApplicationInfo = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
        if ((localApplicationInfo == null) || (localApplicationInfo.metaData == null))
          continue;
        if (applicationId == null)
          applicationId = localApplicationInfo.metaData.getString("com.facebook.sdk.ApplicationId");
        if (appClientToken != null)
          continue;
        appClientToken = localApplicationInfo.metaData.getString("com.facebook.sdk.ClientToken");
        return;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
      }
    }
  }

  static void loadDefaultsFromMetadataIfNeeded(Context paramContext)
  {
    if (!defaultsLoaded)
      loadDefaultsFromMetadata(paramContext);
  }

  static Response publishInstallAndWaitForResponse(Context paramContext, String paramString, boolean paramBoolean)
  {
    if ((paramContext == null) || (paramString == null))
      try
      {
        throw new IllegalArgumentException("Both context and applicationId must be non-null");
      }
      catch (Exception localException)
      {
        Utility.logd("Facebook-publish", localException);
        return new Response(null, null, new FacebookRequestError(null, localException));
      }
    AttributionIdentifiers localAttributionIdentifiers = AttributionIdentifiers.getAttributionIdentifiers(paramContext);
    SharedPreferences localSharedPreferences = paramContext.getSharedPreferences("com.facebook.sdk.attributionTracking", 0);
    String str1 = paramString + "ping";
    String str2 = paramString + "json";
    long l = localSharedPreferences.getLong(str1, 0L);
    String str3 = localSharedPreferences.getString(str2, null);
    if (!paramBoolean)
      setShouldAutoPublishInstall(false);
    GraphObject localGraphObject1 = GraphObject.Factory.create();
    localGraphObject1.setProperty("event", "MOBILE_APP_INSTALL");
    Utility.setAppEventAttributionParameters(localGraphObject1, localAttributionIdentifiers, Utility.getHashedDeviceAndAppID(paramContext, paramString), getLimitEventAndDataUsage(paramContext));
    localGraphObject1.setProperty("auto_publish", Boolean.valueOf(paramBoolean));
    localGraphObject1.setProperty("application_package_name", paramContext.getPackageName());
    Request localRequest = Request.newPostRequest(null, String.format("%s/activities", new Object[] { paramString }), localGraphObject1, null);
    Object localObject;
    if (l != 0L)
    {
      localObject = null;
      if (str3 == null);
    }
    try
    {
      GraphObject localGraphObject2 = GraphObject.Factory.create(new JSONObject(str3));
      localObject = localGraphObject2;
      if (localObject == null)
        return (Response)Response.createResponsesFromString("true", null, new RequestBatch(new Request[] { localRequest }), true).get(0);
      return new Response(null, null, null, localObject, true);
      if ((localAttributionIdentifiers == null) || ((localAttributionIdentifiers.getAndroidAdvertiserId() == null) && (localAttributionIdentifiers.getAttributionId() == null)))
        throw new FacebookException("No attribution id available to send to server.");
      if (!Utility.queryAppSettings(paramString, false).supportsAttribution())
        throw new FacebookException("Install attribution has been disabled on the server.");
      Response localResponse = localRequest.executeAndWait();
      SharedPreferences.Editor localEditor = localSharedPreferences.edit();
      localEditor.putLong(str1, System.currentTimeMillis());
      if ((localResponse.getGraphObject() != null) && (localResponse.getGraphObject().getInnerJSONObject() != null))
        localEditor.putString(str2, localResponse.getGraphObject().getInnerJSONObject().toString());
      localEditor.commit();
      return localResponse;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        localObject = null;
    }
  }

  static void publishInstallAsync(Context paramContext, String paramString, Request.Callback paramCallback)
  {
    Context localContext = paramContext.getApplicationContext();
    getExecutor().execute(new Runnable(localContext, paramString, paramCallback)
    {
      public void run()
      {
        Response localResponse = Settings.publishInstallAndWaitForResponse(this.val$applicationContext, this.val$applicationId, false);
        if (this.val$callback != null)
          new Handler(Looper.getMainLooper()).post(new Runnable(localResponse)
          {
            public void run()
            {
              Settings.2.this.val$callback.onCompleted(this.val$response);
            }
          });
      }
    });
  }

  public static final void removeLoggingBehavior(LoggingBehavior paramLoggingBehavior)
  {
    synchronized (loggingBehaviors)
    {
      loggingBehaviors.remove(paramLoggingBehavior);
      return;
    }
  }

  public static void sdkInitialize(Context paramContext)
  {
    monitorenter;
    try
    {
      boolean bool = sdkInitialized.booleanValue();
      if (bool == true);
      while (true)
      {
        return;
        BoltsMeasurementEventListener.getInstance(paramContext.getApplicationContext());
        sdkInitialized = Boolean.valueOf(true);
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static void setAppVersion(String paramString)
  {
    appVersion = paramString;
  }

  public static void setApplicationId(String paramString)
  {
    applicationId = paramString;
  }

  public static void setClientToken(String paramString)
  {
    appClientToken = paramString;
  }

  public static void setExecutor(Executor paramExecutor)
  {
    Validate.notNull(paramExecutor, "executor");
    synchronized (LOCK)
    {
      executor = paramExecutor;
      return;
    }
  }

  public static void setFacebookDomain(String paramString)
  {
    Log.w(TAG, "WARNING: Calling setFacebookDomain from non-DEBUG code.");
    facebookDomain = paramString;
  }

  public static final void setIsLoggingEnabled(boolean paramBoolean)
  {
    isLoggingEnabled = paramBoolean;
  }

  public static void setLimitEventAndDataUsage(Context paramContext, boolean paramBoolean)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).edit();
    localEditor.putBoolean("limitEventUsage", paramBoolean);
    localEditor.commit();
  }

  public static void setOnProgressThreshold(long paramLong)
  {
    onProgressThreshold.set(paramLong);
  }

  public static void setPlatformCompatibilityEnabled(boolean paramBoolean)
  {
    platformCompatibilityEnabled = paramBoolean;
  }

  @Deprecated
  public static void setShouldAutoPublishInstall(boolean paramBoolean)
  {
    shouldAutoPublishInstall = paramBoolean;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.facebook.Settings
 * JD-Core Version:    0.6.0
 */
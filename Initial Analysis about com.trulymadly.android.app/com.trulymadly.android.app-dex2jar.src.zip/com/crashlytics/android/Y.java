package com.crashlytics.android;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import com.crashlytics.android.internal.ab;
import com.crashlytics.android.internal.q;
import com.crashlytics.android.internal.v;

final class Y
{
  public final String a;
  public final int b;
  public final int c;
  public final int d;

  private Y(String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    this.a = paramString;
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramInt3;
  }

  public static Y a(Context paramContext, String paramString)
  {
    if (paramString != null)
      try
      {
        int i = ab.h(paramContext);
        v.a().b().a("Crashlytics", "App icon resource ID is " + i);
        BitmapFactory.Options localOptions = new BitmapFactory.Options();
        localOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(paramContext.getResources(), i, localOptions);
        Y localY = new Y(paramString, i, localOptions.outWidth, localOptions.outHeight);
        return localY;
      }
      catch (Exception localException)
      {
        v.a().b().a("Crashlytics", "Failed to load icon", localException);
      }
    return null;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.Y
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android;

import com.crashlytics.android.internal.q;

final class G
  implements Runnable
{
  G(v paramv, Runnable paramRunnable)
  {
  }

  public final void run()
  {
    try
    {
      this.a.run();
      return;
    }
    catch (Exception localException)
    {
      com.crashlytics.android.internal.v.a().b().a("Crashlytics", "Failed to execute task.", localException);
    }
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.G
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android;

import com.crashlytics.android.internal.q;
import com.crashlytics.android.internal.r;
import com.crashlytics.android.internal.v;
import java.io.File;
import java.io.FilenameFilter;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

final class aa
{
  static final Map<String, String> a;
  private static final FilenameFilter b = new ab();
  private static final short[] c;
  private final Object d = new Object();
  private final V e;
  private Thread f;

  static
  {
    a = Collections.singletonMap("X-CRASHLYTICS-INVALID-SESSION", "1");
    c = new short[] { 10, 20, 30, 60, 120, 300 };
  }

  public aa(V paramV)
  {
    if (paramV == null)
      throw new IllegalArgumentException("createReportCall must not be null.");
    this.e = paramV;
  }

  final List<Z> a()
  {
    v.a().b().a("Crashlytics", "Checking for crash reports...");
    LinkedList localLinkedList;
    synchronized (this.d)
    {
      File[] arrayOfFile = v.a().h().listFiles(b);
      localLinkedList = new LinkedList();
      int i = arrayOfFile.length;
      int j = 0;
      if (j < i)
      {
        File localFile = arrayOfFile[j];
        v.a().b().a("Crashlytics", "Found crash report " + localFile.getPath());
        localLinkedList.add(new Z(localFile));
        j++;
      }
    }
    v.a().b().a("Crashlytics", "No reports found.");
    return localLinkedList;
  }

  public final void a(float paramFloat)
  {
    monitorenter;
    try
    {
      if (this.f == null)
      {
        this.f = new Thread(new ac(this, paramFloat), "Crashlytics Report Uploader");
        this.f.start();
      }
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  final boolean a(Z paramZ)
  {
    synchronized (this.d)
    {
      try
      {
        U localU = new U(r.a(v.a().getContext(), v.a().f()), paramZ);
        boolean bool = this.e.a(localU);
        q localq = v.a().b();
        StringBuilder localStringBuilder = new StringBuilder("Crashlytics report upload ");
        if (bool);
        for (String str = "complete: "; ; str = "FAILED: ")
        {
          localq.b("Crashlytics", str + paramZ.b());
          i = 0;
          if (bool)
          {
            paramZ.a();
            i = 1;
          }
          return i;
        }
      }
      catch (Exception localException)
      {
        while (true)
        {
          v.a().b().a("Crashlytics", "Error occurred sending report " + paramZ, localException);
          int i = 0;
        }
      }
    }
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.aa
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android;

import java.util.Date;
import java.util.concurrent.atomic.AtomicBoolean;

final class P
  implements Runnable
{
  P(v paramv, Date paramDate, Thread paramThread, Throwable paramThrowable)
  {
  }

  public final void run()
  {
    if (!v.a(this.d).get())
      v.b(this.d, this.a, this.b, this.c);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.P
 * JD-Core Version:    0.6.0
 */
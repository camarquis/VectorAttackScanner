package com.crashlytics.android;

import java.util.concurrent.Callable;

final class z
  implements Callable<Void>
{
  z(v paramv)
  {
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.z
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android;

import java.io.File;
import java.io.FilenameFilter;

final class F
  implements FilenameFilter
{
  F(v paramv, String paramString)
  {
  }

  public final boolean accept(File paramFile, String paramString)
  {
    return paramString.startsWith(this.a);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.F
 * JD-Core Version:    0.6.0
 */
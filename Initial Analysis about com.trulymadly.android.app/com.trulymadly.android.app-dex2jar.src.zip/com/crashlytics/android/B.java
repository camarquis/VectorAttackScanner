package com.crashlytics.android;

import com.crashlytics.android.internal.q;
import java.io.File;
import java.util.concurrent.Callable;

final class B
  implements Callable<Boolean>
{
  B(v paramv)
  {
  }

  private Boolean a()
    throws Exception
  {
    try
    {
      boolean bool = v.f(this.a).delete();
      com.crashlytics.android.internal.v.a().b().a("Crashlytics", "Initialization marker file removed: " + bool);
      Boolean localBoolean = Boolean.valueOf(bool);
      return localBoolean;
    }
    catch (Exception localException)
    {
      com.crashlytics.android.internal.v.a().b().a("Crashlytics", "Problem encountered deleting Crashlytics initialization marker.", localException);
    }
    return Boolean.valueOf(false);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.B
 * JD-Core Version:    0.6.0
 */
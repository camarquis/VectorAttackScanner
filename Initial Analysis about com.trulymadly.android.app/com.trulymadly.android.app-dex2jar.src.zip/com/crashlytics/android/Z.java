package com.crashlytics.android;

import com.crashlytics.android.internal.q;
import com.crashlytics.android.internal.v;
import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

class Z
{
  private final File a;
  private final Map<String, String> b;

  public Z(File paramFile)
  {
    this(paramFile, Collections.emptyMap());
  }

  public Z(File paramFile, Map<String, String> paramMap)
  {
    this.a = paramFile;
    this.b = new HashMap(paramMap);
    if (this.a.length() == 0L)
      this.b.putAll(aa.a);
  }

  public boolean a()
  {
    v.a().b().a("Crashlytics", "Removing report at " + this.a.getPath());
    return this.a.delete();
  }

  public String b()
  {
    return d().getName();
  }

  public String c()
  {
    String str = b();
    return str.substring(0, str.lastIndexOf('.'));
  }

  public File d()
  {
    return this.a;
  }

  public Map<String, String> e()
  {
    return Collections.unmodifiableMap(this.b);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.Z
 * JD-Core Version:    0.6.0
 */
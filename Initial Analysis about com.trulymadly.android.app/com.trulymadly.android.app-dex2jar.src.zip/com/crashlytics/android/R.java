package com.crashlytics.android;

import java.io.File;
import java.io.FilenameFilter;

final class R
  implements FilenameFilter
{
  private final String a;

  public R(String paramString)
  {
    this.a = paramString;
  }

  public final boolean accept(File paramFile, String paramString)
  {
    return (paramString.contains(this.a)) && (!paramString.endsWith(".cls_temp"));
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.R
 * JD-Core Version:    0.6.0
 */
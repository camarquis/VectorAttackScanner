package com.crashlytics.android;

import java.util.concurrent.Callable;

final class x
  implements Callable<Void>
{
  x(v paramv, long paramLong, String paramString)
  {
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.x
 * JD-Core Version:    0.6.0
 */
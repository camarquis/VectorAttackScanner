package com.crashlytics.android;

abstract interface V
{
  public abstract boolean a(U paramU);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.V
 * JD-Core Version:    0.6.0
 */
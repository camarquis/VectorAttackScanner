package com.crashlytics.android.internal;

public final class aX
{
  public final aM a;
  public final aR b;
  public final aQ c;
  public final aP d;
  public final aK e;
  public final long f;

  public aX(long paramLong, aM paramaM, aR paramaR, aQ paramaQ, aP paramaP, aK paramaK, int paramInt1, int paramInt2)
  {
    this.f = paramLong;
    this.a = paramaM;
    this.b = paramaR;
    this.c = paramaQ;
    this.d = paramaP;
    this.e = paramaK;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aX
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android.internal;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

final class X
{
  private static JSONObject a(Map<String, String> paramMap)
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject();
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      localJSONObject.put((String)localEntry.getKey(), localEntry.getValue());
    }
    return localJSONObject;
  }

  public final byte[] a(V paramV)
    throws IOException
  {
    try
    {
      JSONObject localJSONObject = new JSONObject();
      localJSONObject.put("appBundleId", paramV.a);
      localJSONObject.put("executionId", paramV.b);
      localJSONObject.put("installationId", paramV.c);
      localJSONObject.put("androidId", paramV.d);
      localJSONObject.put("osVersion", paramV.e);
      localJSONObject.put("deviceModel", paramV.f);
      localJSONObject.put("appVersionCode", paramV.g);
      localJSONObject.put("appVersionName", paramV.h);
      localJSONObject.put("timestamp", paramV.i);
      localJSONObject.put("type", paramV.j.toString());
      localJSONObject.put("details", a(paramV.k));
      byte[] arrayOfByte = localJSONObject.toString().getBytes("UTF-8");
      return arrayOfByte;
    }
    catch (JSONException localJSONException)
    {
    }
    throw new IOException(localJSONException.getMessage());
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.X
 * JD-Core Version:    0.6.0
 */
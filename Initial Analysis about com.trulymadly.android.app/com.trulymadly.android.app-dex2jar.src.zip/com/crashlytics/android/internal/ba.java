package com.crashlytics.android.internal;

import org.json.JSONObject;

public abstract interface ba
{
  public abstract JSONObject a(aZ paramaZ);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.ba
 * JD-Core Version:    0.6.0
 */
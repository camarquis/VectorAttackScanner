package com.crashlytics.android.internal;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;

public final class aF extends BufferedOutputStream
{
  private final CharsetEncoder a;

  public aF(OutputStream paramOutputStream, String paramString, int paramInt)
  {
    super(paramOutputStream, paramInt);
    this.a = Charset.forName(ay.b(paramString)).newEncoder();
  }

  public final aF a(String paramString)
    throws IOException
  {
    ByteBuffer localByteBuffer = this.a.encode(CharBuffer.wrap(paramString));
    super.write(localByteBuffer.array(), 0, localByteBuffer.limit());
    return this;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aF
 * JD-Core Version:    0.6.0
 */
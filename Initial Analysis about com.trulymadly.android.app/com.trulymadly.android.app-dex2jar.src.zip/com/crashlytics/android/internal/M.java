package com.crashlytics.android.internal;

import java.io.File;

final class M
{
  final File a;
  final long b;

  public M(K paramK, File paramFile, long paramLong)
  {
    this.a = paramFile;
    this.b = paramLong;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.M
 * JD-Core Version:    0.6.0
 */
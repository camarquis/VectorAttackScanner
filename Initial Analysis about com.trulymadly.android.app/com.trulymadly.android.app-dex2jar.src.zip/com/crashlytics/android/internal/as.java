package com.crashlytics.android.internal;

final class as
{
  static final as a = new as(0, 0);
  final int b;
  final int c;

  as(int paramInt1, int paramInt2)
  {
    this.b = paramInt1;
    this.c = paramInt2;
  }

  public final String toString()
  {
    return getClass().getSimpleName() + "[position = " + this.b + ", length = " + this.c + "]";
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.as
 * JD-Core Version:    0.6.0
 */
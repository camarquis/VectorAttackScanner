package com.crashlytics.android.internal;

public final class aZ
{
  public final String a;
  public final String b;
  public final String c;
  public final String d;
  public final String e;
  public final int f;
  public final String g;

  public aZ(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt, String paramString6)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramString4;
    this.e = paramString5;
    this.f = paramInt;
    this.g = paramString6;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aZ
 * JD-Core Version:    0.6.0
 */
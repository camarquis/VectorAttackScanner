package com.crashlytics.android.internal;

public final class aP
{
  public final boolean a;
  public final boolean b;
  public final boolean c;

  public aP(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    this.a = paramBoolean1;
    this.b = paramBoolean3;
    this.c = paramBoolean4;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aP
 * JD-Core Version:    0.6.0
 */
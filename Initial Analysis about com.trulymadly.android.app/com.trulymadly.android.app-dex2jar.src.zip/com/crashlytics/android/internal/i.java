package com.crashlytics.android.internal;

import java.util.Map;
import java.util.Set;

abstract interface i
{
  public static final i a = new j();

  public abstract Map<Class<?>, h> a(Object paramObject);

  public abstract Map<Class<?>, Set<g>> b(Object paramObject);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.i
 * JD-Core Version:    0.6.0
 */
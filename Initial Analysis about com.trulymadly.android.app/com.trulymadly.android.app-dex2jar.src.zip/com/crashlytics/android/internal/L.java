package com.crashlytics.android.internal;

import java.util.Comparator;

final class L
  implements Comparator<M>
{
  L(K paramK)
  {
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.L
 * JD-Core Version:    0.6.0
 */
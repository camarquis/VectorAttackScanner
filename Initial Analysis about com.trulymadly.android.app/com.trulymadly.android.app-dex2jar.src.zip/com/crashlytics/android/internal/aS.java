package com.crashlytics.android.internal;

import android.content.Context;
import android.content.pm.PackageManager;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicReference;

public final class aS
{
  private final AtomicReference<aX> a = new AtomicReference();
  private aW b;
  private boolean c = false;

  public static aS a()
  {
    return aT.a();
  }

  // ERROR //
  private static String a(String paramString1, String paramString2, Context paramContext)
  {
    // Byte code:
    //   0: aload_1
    //   1: ldc 36
    //   3: new 38	java/lang/StringBuffer
    //   6: dup
    //   7: new 40	java/lang/String
    //   10: dup
    //   11: iconst_3
    //   12: newarray char
    //   14: dup
    //   15: iconst_0
    //   16: ldc 41
    //   18: castore
    //   19: dup
    //   20: iconst_1
    //   21: ldc 42
    //   23: castore
    //   24: dup
    //   25: iconst_2
    //   26: ldc 43
    //   28: castore
    //   29: invokespecial 46	java/lang/String:<init>	([C)V
    //   32: invokespecial 49	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
    //   35: invokevirtual 53	java/lang/StringBuffer:reverse	()Ljava/lang/StringBuffer;
    //   38: invokevirtual 57	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   41: invokevirtual 61	java/lang/String:replaceAll	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   44: astore 5
    //   46: iconst_1
    //   47: new 63	java/lang/StringBuilder
    //   50: dup
    //   51: invokespecial 64	java/lang/StringBuilder:<init>	()V
    //   54: aload_0
    //   55: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: aload 5
    //   60: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: invokevirtual 69	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   66: invokestatic 74	com/crashlytics/android/internal/ab:a	(Ljava/lang/String;)Ljava/lang/String;
    //   69: invokestatic 77	com/crashlytics/android/internal/ab:b	(ILjava/lang/String;)Ljavax/crypto/Cipher;
    //   72: astore 6
    //   74: new 79	org/json/JSONObject
    //   77: dup
    //   78: invokespecial 80	org/json/JSONObject:<init>	()V
    //   81: astore 7
    //   83: new 82	com/crashlytics/android/internal/ao
    //   86: dup
    //   87: aload_2
    //   88: invokespecial 85	com/crashlytics/android/internal/ao:<init>	(Landroid/content/Context;)V
    //   91: astore 8
    //   93: aload 7
    //   95: ldc 87
    //   97: getstatic 93	java/util/Locale:US	Ljava/util/Locale;
    //   100: invokevirtual 97	java/lang/String:toLowerCase	(Ljava/util/Locale;)Ljava/lang/String;
    //   103: aload 8
    //   105: invokevirtual 99	com/crashlytics/android/internal/ao:b	()Ljava/lang/String;
    //   108: invokevirtual 103	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   111: pop
    //   112: aload 8
    //   114: invokevirtual 107	com/crashlytics/android/internal/ao:f	()Ljava/util/Map;
    //   117: invokeinterface 113 1 0
    //   122: invokeinterface 119 1 0
    //   127: astore 10
    //   129: aload 10
    //   131: invokeinterface 125 1 0
    //   136: ifeq +144 -> 280
    //   139: aload 10
    //   141: invokeinterface 129 1 0
    //   146: checkcast 131	java/util/Map$Entry
    //   149: astore 17
    //   151: aload 7
    //   153: aload 17
    //   155: invokeinterface 134 1 0
    //   160: checkcast 136	com/crashlytics/android/internal/ap
    //   163: invokevirtual 139	com/crashlytics/android/internal/ap:name	()Ljava/lang/String;
    //   166: getstatic 93	java/util/Locale:US	Ljava/util/Locale;
    //   169: invokevirtual 97	java/lang/String:toLowerCase	(Ljava/util/Locale;)Ljava/lang/String;
    //   172: aload 17
    //   174: invokeinterface 142 1 0
    //   179: invokevirtual 103	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   182: pop
    //   183: goto -54 -> 129
    //   186: astore 18
    //   188: invokestatic 147	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   191: invokevirtual 150	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   194: ldc 152
    //   196: new 63	java/lang/StringBuilder
    //   199: dup
    //   200: ldc 154
    //   202: invokespecial 155	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   205: aload 17
    //   207: invokeinterface 134 1 0
    //   212: checkcast 136	com/crashlytics/android/internal/ap
    //   215: invokevirtual 139	com/crashlytics/android/internal/ap:name	()Ljava/lang/String;
    //   218: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   221: invokevirtual 69	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   224: aload 18
    //   226: invokeinterface 160 4 0
    //   231: goto -102 -> 129
    //   234: astore_3
    //   235: invokestatic 147	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   238: invokevirtual 150	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   241: ldc 152
    //   243: ldc 162
    //   245: aload_3
    //   246: invokeinterface 160 4 0
    //   251: ldc 164
    //   253: astore 4
    //   255: aload 4
    //   257: areturn
    //   258: astore 9
    //   260: invokestatic 147	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   263: invokevirtual 150	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   266: ldc 152
    //   268: ldc 166
    //   270: aload 9
    //   272: invokeinterface 160 4 0
    //   277: goto -165 -> 112
    //   280: aload 7
    //   282: ldc 168
    //   284: aload 8
    //   286: invokevirtual 170	com/crashlytics/android/internal/ao:c	()Ljava/lang/String;
    //   289: invokevirtual 103	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   292: pop
    //   293: aload 7
    //   295: ldc 172
    //   297: aload 8
    //   299: invokevirtual 175	com/crashlytics/android/internal/ao:d	()Ljava/lang/String;
    //   302: invokevirtual 103	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   305: pop
    //   306: ldc 164
    //   308: astore 4
    //   310: aload 7
    //   312: invokevirtual 179	org/json/JSONObject:length	()I
    //   315: ifle -60 -> 255
    //   318: aload 6
    //   320: aload 7
    //   322: invokevirtual 180	org/json/JSONObject:toString	()Ljava/lang/String;
    //   325: invokevirtual 184	java/lang/String:getBytes	()[B
    //   328: invokevirtual 190	javax/crypto/Cipher:doFinal	([B)[B
    //   331: invokestatic 193	com/crashlytics/android/internal/ab:a	([B)Ljava/lang/String;
    //   334: astore 14
    //   336: aload 14
    //   338: areturn
    //   339: astore 11
    //   341: invokestatic 147	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   344: invokevirtual 150	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   347: ldc 152
    //   349: ldc 195
    //   351: aload 11
    //   353: invokeinterface 160 4 0
    //   358: goto -65 -> 293
    //   361: astore 12
    //   363: invokestatic 147	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   366: invokevirtual 150	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   369: ldc 152
    //   371: ldc 197
    //   373: aload 12
    //   375: invokeinterface 160 4 0
    //   380: goto -74 -> 306
    //   383: astore 13
    //   385: invokestatic 147	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   388: invokevirtual 150	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   391: ldc 152
    //   393: ldc 199
    //   395: aload 13
    //   397: invokeinterface 160 4 0
    //   402: aload 4
    //   404: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   151	183	186	java/lang/Exception
    //   0	74	234	java/security/GeneralSecurityException
    //   93	112	258	java/lang/Exception
    //   280	293	339	java/lang/Exception
    //   293	306	361	java/lang/Exception
    //   318	336	383	java/security/GeneralSecurityException
  }

  public final aS a(Context paramContext, av paramav, String paramString1, String paramString2, String paramString3)
  {
    monitorenter;
    try
    {
      boolean bool = this.c;
      if (bool);
      for (aS localaS = this; ; localaS = this)
      {
        return localaS;
        if (this.b == null)
        {
          String str1 = r.a(paramContext, false);
          String str2 = paramContext.getPackageName();
          String str3 = paramContext.getPackageManager().getInstallerPackageName(str2);
          ah localah = new ah();
          aY localaY = new aY();
          aN localaN = new aN();
          String str4 = ab.g(paramContext);
          aO localaO = new aO(paramString3, String.format(Locale.US, "https://settings.crashlytics.com/spi/v2/platforms/android/apps/%s/settings", new Object[] { str2 }), paramav);
          String str5 = a(str1, str2, paramContext);
          String[] arrayOfString = new String[1];
          arrayOfString[0] = ab.i(paramContext);
          this.b = new aW(new aZ(str1, str5, ab.a(arrayOfString), paramString2, paramString1, ai.a(str3).a(), str4), localah, localaY, localaN, localaO);
        }
        this.c = true;
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public final <T> T a(aU<T> paramaU, T paramT)
  {
    aX localaX = (aX)this.a.get();
    if (localaX == null)
      return paramT;
    return paramaU.a(localaX);
  }

  public final aX b()
  {
    return (aX)this.a.get();
  }

  public final boolean c()
  {
    monitorenter;
    try
    {
      aX localaX = this.b.a();
      this.a.set(localaX);
      if (localaX != null)
      {
        i = 1;
        return i;
      }
      int i = 0;
    }
    finally
    {
      monitorexit;
    }
  }

  public final boolean d()
  {
    monitorenter;
    try
    {
      aX localaX = this.b.a(aV.b);
      this.a.set(localaX);
      if (localaX == null)
        v.a().b().a("Crashlytics", "Failed to force reload of settings from Crashlytics.", null);
      if (localaX != null);
      for (int i = 1; ; i = 0)
        return i;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aS
 * JD-Core Version:    0.6.0
 */
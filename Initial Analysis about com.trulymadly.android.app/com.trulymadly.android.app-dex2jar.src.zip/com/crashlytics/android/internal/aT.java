package com.crashlytics.android.internal;

final class aT
{
  private static final aS a = new aS(0);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aT
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android.internal;

public abstract interface ak
{
  public abstract void c();
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.ak
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android.internal;

import java.io.IOException;
import java.io.InputStream;

public abstract interface au
{
  public abstract void a(InputStream paramInputStream, int paramInt)
    throws IOException;
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.au
 * JD-Core Version:    0.6.0
 */
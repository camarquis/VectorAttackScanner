package com.crashlytics.android.internal;

final class e
{
  final Object a;
  final g b;

  public e(Object paramObject, g paramg)
  {
    this.a = paramObject;
    this.b = paramg;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.e
 * JD-Core Version:    0.6.0
 */
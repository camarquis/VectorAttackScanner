package com.crashlytics.android.internal;

final class T
  implements Runnable
{
  T(O paramO)
  {
  }

  public final void run()
  {
    try
    {
      U localU = this.a.a;
      this.a.a = new I();
      localU.b();
      return;
    }
    catch (Exception localException)
    {
      ab.d("Crashlytics failed to disable analytics.");
    }
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.T
 * JD-Core Version:    0.6.0
 */
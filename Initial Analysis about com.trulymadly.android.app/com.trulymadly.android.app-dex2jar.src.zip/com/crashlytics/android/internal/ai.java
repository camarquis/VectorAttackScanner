package com.crashlytics.android.internal;

public enum ai
{
  private final int e;

  static
  {
    ai[] arrayOfai = new ai[4];
    arrayOfai[0] = a;
    arrayOfai[1] = b;
    arrayOfai[2] = c;
    arrayOfai[3] = d;
    f = arrayOfai;
  }

  private ai(int paramInt)
  {
    this.e = paramInt;
  }

  public static ai a(String paramString)
  {
    if (paramString != null);
    for (int i = 1; i != 0; i = 0)
      return d;
    return a;
  }

  public final int a()
  {
    return this.e;
  }

  public final String toString()
  {
    return Integer.toString(this.e);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.ai
 * JD-Core Version:    0.6.0
 */
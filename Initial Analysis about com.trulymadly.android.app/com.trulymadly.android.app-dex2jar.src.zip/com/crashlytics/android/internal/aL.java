package com.crashlytics.android.internal;

final class aL
{
  public aL(String paramString, int paramInt1, int paramInt2)
  {
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aL
 * JD-Core Version:    0.6.0
 */
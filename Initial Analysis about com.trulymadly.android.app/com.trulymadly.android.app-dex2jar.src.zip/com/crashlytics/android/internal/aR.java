package com.crashlytics.android.internal;

public final class aR
{
  public final int a;

  public aR(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean)
  {
    this.a = paramInt3;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aR
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android.internal;

import org.json.JSONException;
import org.json.JSONObject;

public class aY
{
  public aX a(ah paramah, JSONObject paramJSONObject)
    throws JSONException
  {
    int i = paramJSONObject.optInt("settings_version", 0);
    int j = paramJSONObject.optInt("cache_duration", 3600);
    JSONObject localJSONObject1 = paramJSONObject.getJSONObject("app");
    String str1 = localJSONObject1.getString("identifier");
    String str2 = localJSONObject1.getString("status");
    String str3 = localJSONObject1.getString("url");
    String str4 = localJSONObject1.getString("reports_url");
    boolean bool1 = localJSONObject1.optBoolean("update_required", false);
    boolean bool2 = localJSONObject1.has("icon");
    aL localaL = null;
    if (bool2)
    {
      boolean bool3 = localJSONObject1.getJSONObject("icon").has("hash");
      localaL = null;
      if (bool3)
      {
        JSONObject localJSONObject6 = localJSONObject1.getJSONObject("icon");
        localaL = new aL(localJSONObject6.getString("hash"), localJSONObject6.getInt("width"), localJSONObject6.getInt("height"));
      }
    }
    aM localaM = new aM(str1, str2, str3, str4, bool1, localaL);
    JSONObject localJSONObject2 = paramJSONObject.getJSONObject("session");
    aR localaR = new aR(localJSONObject2.optInt("log_buffer_size", 64000), localJSONObject2.optInt("max_chained_exception_depth", 8), localJSONObject2.optInt("max_custom_exception_events", 64), localJSONObject2.optInt("max_custom_key_value_pairs", 64), localJSONObject2.optInt("identifier_mask", 255), localJSONObject2.optBoolean("send_session_without_crash", false));
    JSONObject localJSONObject3 = paramJSONObject.getJSONObject("prompt");
    aQ localaQ = new aQ(localJSONObject3.optString("title", "Send Crash Report?"), localJSONObject3.optString("message", "Looks like we crashed! Please help us fix the problem by sending a crash report."), localJSONObject3.optString("send_button_title", "Send"), localJSONObject3.optBoolean("show_cancel_button", true), localJSONObject3.optString("cancel_button_title", "Don't Send"), localJSONObject3.optBoolean("show_always_send_button", true), localJSONObject3.optString("always_send_button_title", "Always Send"));
    JSONObject localJSONObject4 = paramJSONObject.getJSONObject("features");
    aP localaP = new aP(localJSONObject4.optBoolean("prompt_enabled", false), localJSONObject4.optBoolean("collect_logged_exceptions", true), localJSONObject4.optBoolean("collect_reports", true), localJSONObject4.optBoolean("collect_analytics", false));
    JSONObject localJSONObject5 = paramJSONObject.getJSONObject("analytics");
    aK localaK = new aK(localJSONObject5.optString("url", "https://e.crashlytics.com/spi/v2/events"), localJSONObject5.optInt("flush_interval_secs", 600), localJSONObject5.optInt("max_byte_size_per_file", 8000), localJSONObject5.optInt("max_file_count_per_send", 1), localJSONObject5.optInt("max_pending_send_file_count", 100));
    long l1 = j;
    long l2;
    if (paramJSONObject.has("expires_at"))
      l2 = paramJSONObject.getLong("expires_at");
    while (true)
    {
      return new aX(l2, localaM, localaR, localaQ, localaP, localaK, i, j);
      l2 = paramah.a() + l1 * 1000L;
    }
  }

  public JSONObject a(JSONObject paramJSONObject)
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject(paramJSONObject.toString());
    localJSONObject.getJSONObject("features").remove("collect_analytics");
    localJSONObject.remove("analytics");
    return localJSONObject;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aY
 * JD-Core Version:    0.6.0
 */
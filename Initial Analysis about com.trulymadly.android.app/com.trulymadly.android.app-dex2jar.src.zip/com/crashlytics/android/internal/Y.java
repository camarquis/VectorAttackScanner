package com.crashlytics.android.internal;

final class Y
  implements Runnable
{
  private final K a;
  private final U b;

  public Y(K paramK, U paramU)
  {
    this.a = paramK;
    this.b = paramU;
  }

  public final void run()
  {
    try
    {
      ab.c("Performing time based analytics file roll over.");
      if (!this.a.a())
        this.b.c();
      return;
    }
    catch (Exception localException)
    {
      ab.d("Crashlytics failed to roll over session analytics file");
    }
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.Y
 * JD-Core Version:    0.6.0
 */
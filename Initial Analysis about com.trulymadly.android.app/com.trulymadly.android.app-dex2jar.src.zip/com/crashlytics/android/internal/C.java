package com.crashlytics.android.internal;

final class C
  implements Runnable
{
  C(B paramB, t paramt)
  {
  }

  public final void run()
  {
    B.a(this.b, this.a);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.C
 * JD-Core Version:    0.6.0
 */
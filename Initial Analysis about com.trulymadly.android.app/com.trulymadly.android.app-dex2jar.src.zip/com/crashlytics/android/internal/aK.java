package com.crashlytics.android.internal;

public class aK
{
  public final String a;
  public final int b;
  public final int c;

  public aK(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.a = paramString;
    this.b = paramInt1;
    this.c = paramInt2;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aK
 * JD-Core Version:    0.6.0
 */
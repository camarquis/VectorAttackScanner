package com.crashlytics.android.internal;

import java.io.File;
import java.util.Comparator;

final class ac
  implements Comparator<File>
{
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.ac
 * JD-Core Version:    0.6.0
 */
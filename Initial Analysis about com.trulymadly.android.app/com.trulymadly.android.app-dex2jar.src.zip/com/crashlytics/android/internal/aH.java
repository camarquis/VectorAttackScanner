package com.crashlytics.android.internal;

import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

final class aH
  implements X509TrustManager
{
  private final TrustManager[] a;
  private final aI b;
  private final long c;
  private final List<byte[]> d = new LinkedList();
  private final Set<X509Certificate> e = Collections.synchronizedSet(new HashSet());

  public aH(aI paramaI, aG paramaG)
  {
    this.a = a(paramaI);
    this.b = paramaI;
    this.c = -1L;
    for (String str : paramaG.c())
      this.d.add(a(str));
  }

  private boolean a(X509Certificate paramX509Certificate)
    throws CertificateException
  {
    try
    {
      byte[] arrayOfByte = MessageDigest.getInstance("SHA1").digest(paramX509Certificate.getPublicKey().getEncoded());
      Iterator localIterator = this.d.iterator();
      while (localIterator.hasNext())
      {
        boolean bool = Arrays.equals((byte[])localIterator.next(), arrayOfByte);
        if (bool)
          return true;
      }
      return false;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
    }
    throw new CertificateException(localNoSuchAlgorithmException);
  }

  private static byte[] a(String paramString)
  {
    int i = paramString.length();
    byte[] arrayOfByte = new byte[i / 2];
    for (int j = 0; j < i; j += 2)
      arrayOfByte[(j / 2)] = (byte)((Character.digit(paramString.charAt(j), 16) << 4) + Character.digit(paramString.charAt(j + 1), 16));
    return arrayOfByte;
  }

  private static TrustManager[] a(aI paramaI)
  {
    try
    {
      TrustManagerFactory localTrustManagerFactory = TrustManagerFactory.getInstance("X509");
      localTrustManagerFactory.init(paramaI.a);
      TrustManager[] arrayOfTrustManager = localTrustManagerFactory.getTrustManagers();
      return arrayOfTrustManager;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new AssertionError(localNoSuchAlgorithmException);
    }
    catch (KeyStoreException localKeyStoreException)
    {
    }
    throw new AssertionError(localKeyStoreException);
  }

  public final void checkClientTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString)
    throws CertificateException
  {
    throw new CertificateException("Client certificates not supported!");
  }

  public final void checkServerTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString)
    throws CertificateException
  {
    if (this.e.contains(paramArrayOfX509Certificate[0]))
      return;
    TrustManager[] arrayOfTrustManager = this.a;
    int i = arrayOfTrustManager.length;
    for (int j = 0; j < i; j++)
      ((X509TrustManager)arrayOfTrustManager[j]).checkServerTrusted(paramArrayOfX509Certificate, paramString);
    if ((this.c != -1L) && (System.currentTimeMillis() - this.c > 15552000000L))
    {
      v.a().b().c("Crashlytics", "Certificate pins are stale, (" + (System.currentTimeMillis() - this.c) + " millis vs 15552000000" + " millis) falling back to system trust.");
      this.e.add(paramArrayOfX509Certificate[0]);
      return;
    }
    X509Certificate[] arrayOfX509Certificate = av.a(paramArrayOfX509Certificate, this.b);
    int k = arrayOfX509Certificate.length;
    for (int m = 0; ; m++)
    {
      if (m >= k)
        break label184;
      if (a(arrayOfX509Certificate[m]))
        break;
    }
    label184: throw new CertificateException("No valid pins found in chain!");
  }

  public final X509Certificate[] getAcceptedIssuers()
  {
    return null;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aH
 * JD-Core Version:    0.6.0
 */
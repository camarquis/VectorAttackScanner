package com.crashlytics.android.internal;

public abstract interface q
{
  public abstract void a(int paramInt, String paramString1, String paramString2);

  public abstract void a(int paramInt, String paramString1, String paramString2, boolean paramBoolean);

  public abstract void a(String paramString1, String paramString2);

  public abstract void a(String paramString1, String paramString2, Throwable paramThrowable);

  public abstract void b(String paramString1, String paramString2);

  public abstract void c(String paramString1, String paramString2);

  public abstract void d(String paramString1, String paramString2);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.q
 * JD-Core Version:    0.6.0
 */
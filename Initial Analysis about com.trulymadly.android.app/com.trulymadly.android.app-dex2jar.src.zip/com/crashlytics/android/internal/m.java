package com.crashlytics.android.internal;

public abstract interface m
{
  public static final m a = new n();
  public static final m b = new o();

  public abstract void a(b paramb);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.m
 * JD-Core Version:    0.6.0
 */
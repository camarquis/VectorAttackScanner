package com.crashlytics.android.internal;

final class R
  implements Runnable
{
  R(O paramO, aK paramaK, String paramString)
  {
  }

  public final void run()
  {
    try
    {
      this.c.a.a(this.a, this.b);
      return;
    }
    catch (Exception localException)
    {
      ab.d("Crashlytics failed to set analytics settings data.");
    }
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.R
 * JD-Core Version:    0.6.0
 */
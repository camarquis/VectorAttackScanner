package com.crashlytics.android.internal;

import java.io.IOException;

public final class aD extends RuntimeException
{
  private static final long serialVersionUID = -1170466989781746231L;

  protected aD(IOException paramIOException)
  {
    super(paramIOException);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aD
 * JD-Core Version:    0.6.0
 */
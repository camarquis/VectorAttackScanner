package com.crashlytics.android.internal;

import android.os.Process;

public abstract class aa
  implements Runnable
{
  protected abstract void a();

  public final void run()
  {
    Process.setThreadPriority(10);
    a();
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aa
 * JD-Core Version:    0.6.0
 */
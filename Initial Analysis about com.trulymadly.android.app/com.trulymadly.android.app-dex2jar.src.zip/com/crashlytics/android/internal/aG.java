package com.crashlytics.android.internal;

import java.io.InputStream;

public abstract interface aG
{
  public abstract InputStream a();

  public abstract String b();

  public abstract String[] c();
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aG
 * JD-Core Version:    0.6.0
 */
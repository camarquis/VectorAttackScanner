package com.crashlytics.android.internal;

public final class aM
{
  public final String a;
  public final String b;
  public final String c;
  public final boolean d;

  public aM(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean, aL paramaL)
  {
    this.a = paramString2;
    this.b = paramString3;
    this.c = paramString4;
    this.d = paramBoolean;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aM
 * JD-Core Version:    0.6.0
 */
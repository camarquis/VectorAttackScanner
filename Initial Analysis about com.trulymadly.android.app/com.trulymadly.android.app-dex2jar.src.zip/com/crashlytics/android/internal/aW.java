package com.crashlytics.android.internal;

import org.json.JSONException;
import org.json.JSONObject;

public class aW
{
  private aZ a;
  private final aY b;
  private final ah c;
  private final aN d;
  private final ba e;

  public aW(aZ paramaZ, ah paramah, aY paramaY, aN paramaN, ba paramba)
  {
    this.a = paramaZ;
    this.c = paramah;
    this.b = paramaY;
    this.d = paramaN;
    this.e = paramba;
  }

  private void a(JSONObject paramJSONObject, String paramString)
    throws JSONException
  {
    if (!ab.e(v.a().getContext()))
      paramJSONObject = this.b.a(paramJSONObject);
    v.a().b().a("Crashlytics", paramString + paramJSONObject.toString());
  }

  // ERROR //
  private aX b(aV paramaV)
  {
    // Byte code:
    //   0: getstatic 83	com/crashlytics/android/internal/aV:b	Lcom/crashlytics/android/internal/aV;
    //   3: aload_1
    //   4: invokevirtual 87	com/crashlytics/android/internal/aV:equals	(Ljava/lang/Object;)Z
    //   7: ifne +191 -> 198
    //   10: aload_0
    //   11: getfield 27	com/crashlytics/android/internal/aW:d	Lcom/crashlytics/android/internal/aN;
    //   14: invokevirtual 92	com/crashlytics/android/internal/aN:a	()Lorg/json/JSONObject;
    //   17: astore 5
    //   19: aload 5
    //   21: ifnull +129 -> 150
    //   24: aload_0
    //   25: getfield 25	com/crashlytics/android/internal/aW:b	Lcom/crashlytics/android/internal/aY;
    //   28: aload_0
    //   29: getfield 23	com/crashlytics/android/internal/aW:c	Lcom/crashlytics/android/internal/ah;
    //   32: aload 5
    //   34: invokevirtual 95	com/crashlytics/android/internal/aY:a	(Lcom/crashlytics/android/internal/ah;Lorg/json/JSONObject;)Lcom/crashlytics/android/internal/aX;
    //   37: astore_3
    //   38: aload_3
    //   39: ifnull +93 -> 132
    //   42: aload_0
    //   43: aload 5
    //   45: ldc 97
    //   47: invokespecial 99	com/crashlytics/android/internal/aW:a	(Lorg/json/JSONObject;Ljava/lang/String;)V
    //   50: aload_0
    //   51: getfield 23	com/crashlytics/android/internal/aW:c	Lcom/crashlytics/android/internal/ah;
    //   54: invokevirtual 104	com/crashlytics/android/internal/ah:a	()J
    //   57: lstore 6
    //   59: getstatic 106	com/crashlytics/android/internal/aV:c	Lcom/crashlytics/android/internal/aV;
    //   62: aload_1
    //   63: invokevirtual 87	com/crashlytics/android/internal/aV:equals	(Ljava/lang/Object;)Z
    //   66: ifne +25 -> 91
    //   69: aload_3
    //   70: getfield 112	com/crashlytics/android/internal/aX:f	J
    //   73: lstore 8
    //   75: lload 8
    //   77: lload 6
    //   79: lcmp
    //   80: ifge +28 -> 108
    //   83: iconst_1
    //   84: istore 10
    //   86: iload 10
    //   88: ifne +26 -> 114
    //   91: invokestatic 37	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   94: invokevirtual 54	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   97: ldc 56
    //   99: ldc 114
    //   101: invokeinterface 75 3 0
    //   106: aload_3
    //   107: areturn
    //   108: iconst_0
    //   109: istore 10
    //   111: goto -25 -> 86
    //   114: invokestatic 37	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   117: invokevirtual 54	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   120: ldc 56
    //   122: ldc 116
    //   124: invokeinterface 75 3 0
    //   129: goto +69 -> 198
    //   132: invokestatic 37	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   135: invokevirtual 54	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   138: ldc 56
    //   140: ldc 118
    //   142: aconst_null
    //   143: invokeinterface 121 4 0
    //   148: aconst_null
    //   149: areturn
    //   150: invokestatic 37	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   153: invokevirtual 54	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   156: ldc 56
    //   158: ldc 123
    //   160: invokeinterface 75 3 0
    //   165: goto +33 -> 198
    //   168: astore_2
    //   169: aconst_null
    //   170: astore_3
    //   171: aload_2
    //   172: astore 4
    //   174: invokestatic 37	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   177: invokevirtual 54	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   180: ldc 56
    //   182: ldc 125
    //   184: aload 4
    //   186: invokeinterface 121 4 0
    //   191: aload_3
    //   192: areturn
    //   193: astore 4
    //   195: goto -21 -> 174
    //   198: aconst_null
    //   199: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	19	168	java/lang/Exception
    //   24	38	168	java/lang/Exception
    //   42	75	168	java/lang/Exception
    //   114	129	168	java/lang/Exception
    //   132	148	168	java/lang/Exception
    //   150	165	168	java/lang/Exception
    //   91	106	193	java/lang/Exception
  }

  public aX a()
  {
    return a(aV.a);
  }

  // ERROR //
  public aX a(aV paramaV)
  {
    // Byte code:
    //   0: invokestatic 37	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   3: invokevirtual 133	com/crashlytics/android/internal/v:f	()Z
    //   6: istore 5
    //   8: aconst_null
    //   9: astore 6
    //   11: iload 5
    //   13: ifne +14 -> 27
    //   16: aload_0
    //   17: aload_1
    //   18: invokespecial 135	com/crashlytics/android/internal/aW:b	(Lcom/crashlytics/android/internal/aV;)Lcom/crashlytics/android/internal/aX;
    //   21: astore 7
    //   23: aload 7
    //   25: astore 6
    //   27: aload 6
    //   29: ifnonnull +60 -> 89
    //   32: aload_0
    //   33: getfield 29	com/crashlytics/android/internal/aW:e	Lcom/crashlytics/android/internal/ba;
    //   36: aload_0
    //   37: getfield 21	com/crashlytics/android/internal/aW:a	Lcom/crashlytics/android/internal/aZ;
    //   40: invokeinterface 140 2 0
    //   45: astore 10
    //   47: aload 10
    //   49: ifnull +40 -> 89
    //   52: aload_0
    //   53: getfield 25	com/crashlytics/android/internal/aW:b	Lcom/crashlytics/android/internal/aY;
    //   56: aload_0
    //   57: getfield 23	com/crashlytics/android/internal/aW:c	Lcom/crashlytics/android/internal/ah;
    //   60: aload 10
    //   62: invokevirtual 95	com/crashlytics/android/internal/aY:a	(Lcom/crashlytics/android/internal/ah;Lorg/json/JSONObject;)Lcom/crashlytics/android/internal/aX;
    //   65: astore 6
    //   67: aload_0
    //   68: getfield 27	com/crashlytics/android/internal/aW:d	Lcom/crashlytics/android/internal/aN;
    //   71: aload 6
    //   73: getfield 112	com/crashlytics/android/internal/aX:f	J
    //   76: aload 10
    //   78: invokevirtual 143	com/crashlytics/android/internal/aN:a	(JLorg/json/JSONObject;)V
    //   81: aload_0
    //   82: aload 10
    //   84: ldc 145
    //   86: invokespecial 99	com/crashlytics/android/internal/aW:a	(Lorg/json/JSONObject;Ljava/lang/String;)V
    //   89: aload 6
    //   91: astore_3
    //   92: aload_3
    //   93: ifnonnull +15 -> 108
    //   96: aload_0
    //   97: getstatic 106	com/crashlytics/android/internal/aV:c	Lcom/crashlytics/android/internal/aV;
    //   100: invokespecial 135	com/crashlytics/android/internal/aW:b	(Lcom/crashlytics/android/internal/aV;)Lcom/crashlytics/android/internal/aX;
    //   103: astore 8
    //   105: aload 8
    //   107: astore_3
    //   108: aload_3
    //   109: areturn
    //   110: astore_2
    //   111: aconst_null
    //   112: astore_3
    //   113: aload_2
    //   114: astore 4
    //   116: invokestatic 37	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   119: invokevirtual 54	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   122: ldc 56
    //   124: ldc 147
    //   126: aload 4
    //   128: invokeinterface 121 4 0
    //   133: aload_3
    //   134: areturn
    //   135: astore 9
    //   137: aload 6
    //   139: astore_3
    //   140: aload 9
    //   142: astore 4
    //   144: goto -28 -> 116
    //   147: astore 4
    //   149: goto -33 -> 116
    //
    // Exception table:
    //   from	to	target	type
    //   0	8	110	java/lang/Exception
    //   16	23	110	java/lang/Exception
    //   32	47	135	java/lang/Exception
    //   52	89	135	java/lang/Exception
    //   96	105	147	java/lang/Exception
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aW
 * JD-Core Version:    0.6.0
 */
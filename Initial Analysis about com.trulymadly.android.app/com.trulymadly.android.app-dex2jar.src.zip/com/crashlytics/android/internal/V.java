package com.crashlytics.android.internal;

import java.util.Map;

final class V
{
  public final String a;
  public final String b;
  public final String c;
  public final String d;
  public final String e;
  public final String f;
  public final String g;
  public final String h;
  public final long i;
  public final W j;
  public final Map<String, String> k;
  private String l;

  private V(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, long paramLong, W paramW, Map<String, String> paramMap)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramString4;
    this.e = paramString5;
    this.f = paramString6;
    this.g = paramString7;
    this.h = paramString8;
    this.i = paramLong;
    this.j = paramW;
    this.k = paramMap;
  }

  public static final V a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, W paramW, Map<String, String> paramMap)
  {
    return new V(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7, paramString8, System.currentTimeMillis(), paramW, paramMap);
  }

  public final String toString()
  {
    if (this.l == null)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append(getClass().getSimpleName());
      localStringBuilder.append(": appBundleId=");
      localStringBuilder.append(this.a);
      localStringBuilder.append(", executionId=");
      localStringBuilder.append(this.b);
      localStringBuilder.append(", installationId=");
      localStringBuilder.append(this.c);
      localStringBuilder.append(", androidId=");
      localStringBuilder.append(this.d);
      localStringBuilder.append(", osVersion=");
      localStringBuilder.append(this.e);
      localStringBuilder.append(", deviceModel=");
      localStringBuilder.append(this.f);
      localStringBuilder.append(", appVersionCode=");
      localStringBuilder.append(this.g);
      localStringBuilder.append(", appVersionName=");
      localStringBuilder.append(this.h);
      localStringBuilder.append(", timestamp=");
      localStringBuilder.append(this.i);
      localStringBuilder.append(", type=");
      localStringBuilder.append(this.j);
      localStringBuilder.append(", details=");
      localStringBuilder.append(this.k.toString());
      localStringBuilder.append("]");
      this.l = localStringBuilder.toString();
    }
    return this.l;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.V
 * JD-Core Version:    0.6.0
 */
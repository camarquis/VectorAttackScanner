package com.crashlytics.android.internal;

public class f
{
  public final Object a;
  public final Object b;

  public f(Object paramObject1, Object paramObject2)
  {
    this.a = paramObject1;
    this.b = paramObject2;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.f
 * JD-Core Version:    0.6.0
 */
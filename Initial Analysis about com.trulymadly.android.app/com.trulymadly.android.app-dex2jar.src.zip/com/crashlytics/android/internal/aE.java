package com.crashlytics.android.internal;

import java.io.IOException;
import java.util.concurrent.Callable;

public abstract class aE<V>
  implements Callable<V>
{
  protected abstract V a()
    throws aD, IOException;

  protected abstract void b()
    throws IOException;

  // ERROR //
  public V call()
    throws aD
  {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: aload_0
    //   3: invokevirtual 21	com/crashlytics/android/internal/aE:a	()Ljava/lang/Object;
    //   6: astore 6
    //   8: aload_0
    //   9: invokevirtual 23	com/crashlytics/android/internal/aE:b	()V
    //   12: aload 6
    //   14: areturn
    //   15: astore 7
    //   17: new 15	com/crashlytics/android/internal/aD
    //   20: dup
    //   21: aload 7
    //   23: invokespecial 26	com/crashlytics/android/internal/aD:<init>	(Ljava/io/IOException;)V
    //   26: athrow
    //   27: astore 5
    //   29: aload 5
    //   31: athrow
    //   32: astore_2
    //   33: aload_0
    //   34: invokevirtual 23	com/crashlytics/android/internal/aE:b	()V
    //   37: aload_2
    //   38: athrow
    //   39: astore 4
    //   41: new 15	com/crashlytics/android/internal/aD
    //   44: dup
    //   45: aload 4
    //   47: invokespecial 26	com/crashlytics/android/internal/aD:<init>	(Ljava/io/IOException;)V
    //   50: athrow
    //   51: astore_3
    //   52: iload_1
    //   53: ifne -16 -> 37
    //   56: new 15	com/crashlytics/android/internal/aD
    //   59: dup
    //   60: aload_3
    //   61: invokespecial 26	com/crashlytics/android/internal/aD:<init>	(Ljava/io/IOException;)V
    //   64: athrow
    //   65: astore_2
    //   66: iconst_0
    //   67: istore_1
    //   68: goto -35 -> 33
    //
    // Exception table:
    //   from	to	target	type
    //   8	12	15	java/io/IOException
    //   2	8	27	com/crashlytics/android/internal/aD
    //   29	32	32	finally
    //   41	51	32	finally
    //   2	8	39	java/io/IOException
    //   33	37	51	java/io/IOException
    //   2	8	65	finally
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aE
 * JD-Core Version:    0.6.0
 */
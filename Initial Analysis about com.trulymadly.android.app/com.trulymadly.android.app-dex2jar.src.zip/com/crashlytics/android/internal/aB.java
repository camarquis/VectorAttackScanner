package com.crashlytics.android.internal;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public abstract interface aB
{
  public static final aB a = new aC();

  public abstract HttpURLConnection a(URL paramURL)
    throws IOException;
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.internal.aB
 * JD-Core Version:    0.6.0
 */
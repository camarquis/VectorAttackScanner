package com.crashlytics.android;

import com.crashlytics.android.internal.q;
import java.util.concurrent.Callable;

final class I
  implements Callable<T>
{
  I(v paramv, Callable paramCallable)
  {
  }

  public final T call()
    throws Exception
  {
    try
    {
      Object localObject = this.a.call();
      return localObject;
    }
    catch (Exception localException)
    {
      com.crashlytics.android.internal.v.a().b().a("Crashlytics", "Failed to execute task.", localException);
    }
    return null;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.I
 * JD-Core Version:    0.6.0
 */
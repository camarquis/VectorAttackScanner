package com.crashlytics.android;

import java.util.concurrent.Callable;

final class C
  implements Callable<Boolean>
{
  C(v paramv)
  {
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.C
 * JD-Core Version:    0.6.0
 */
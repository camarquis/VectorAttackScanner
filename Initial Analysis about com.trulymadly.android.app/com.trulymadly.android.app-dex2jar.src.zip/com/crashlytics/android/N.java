package com.crashlytics.android;

import java.util.Date;
import java.util.concurrent.Callable;

final class N
  implements Callable<Void>
{
  N(v paramv, Date paramDate, Thread paramThread, Throwable paramThrowable)
  {
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.N
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android;

import java.io.IOException;

final class i extends IOException
{
  private static final long serialVersionUID = -6947486886997889499L;

  i()
  {
    super("CodedOutputStream was writing to a flat byte array and ran out of space.");
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.i
 * JD-Core Version:    0.6.0
 */
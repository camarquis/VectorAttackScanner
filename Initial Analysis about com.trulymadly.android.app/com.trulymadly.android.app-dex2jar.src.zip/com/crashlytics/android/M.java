package com.crashlytics.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

final class M extends BroadcastReceiver
{
  M(v paramv)
  {
  }

  public final void onReceive(Context paramContext, Intent paramIntent)
  {
    v.a(this.a, false);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.M
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android;

import java.util.concurrent.Callable;

final class O
  implements Callable<Boolean>
{
  O(v paramv)
  {
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.O
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android;

final class U
{
  public final String a;
  public final Z b;

  public U(String paramString, Z paramZ)
  {
    this.a = paramString;
    this.b = paramZ;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.U
 * JD-Core Version:    0.6.0
 */
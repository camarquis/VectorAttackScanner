package com.crashlytics.android;

final class E
  implements Runnable
{
  E(v paramv)
  {
  }

  public final void run()
  {
    this.a.a(v.a(this.a, f.a));
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.E
 * JD-Core Version:    0.6.0
 */
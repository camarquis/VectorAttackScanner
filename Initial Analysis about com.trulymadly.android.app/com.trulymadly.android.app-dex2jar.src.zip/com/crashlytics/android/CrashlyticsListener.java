package com.crashlytics.android;

public abstract interface CrashlyticsListener
{
  public abstract void crashlyticsDidDetectCrashDuringPreviousExecution();
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.CrashlyticsListener
 * JD-Core Version:    0.6.0
 */
package com.crashlytics.android;

import java.io.File;
import java.util.Comparator;

final class J
  implements Comparator<File>
{
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.crashlytics.android.J
 * JD-Core Version:    0.6.0
 */
package com.google.ads.mediation.customevent;

@Deprecated
public abstract interface CustomEvent
{
  public abstract void destroy();
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.ads.mediation.customevent.CustomEvent
 * JD-Core Version:    0.6.0
 */
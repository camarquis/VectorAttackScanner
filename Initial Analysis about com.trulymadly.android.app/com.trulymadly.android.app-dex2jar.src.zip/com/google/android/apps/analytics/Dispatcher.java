package com.google.android.apps.analytics;

abstract interface Dispatcher
{
  public abstract void dispatchEvents(Event[] paramArrayOfEvent);

  public abstract void init(Callbacks paramCallbacks, String paramString);

  public abstract boolean isDryRun();

  public abstract void setDryRun(boolean paramBoolean);

  public abstract void stop();

  public static abstract interface Callbacks
  {
    public abstract void dispatchFinished();

    public abstract void eventDispatched(long paramLong);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.apps.analytics.Dispatcher
 * JD-Core Version:    0.6.0
 */
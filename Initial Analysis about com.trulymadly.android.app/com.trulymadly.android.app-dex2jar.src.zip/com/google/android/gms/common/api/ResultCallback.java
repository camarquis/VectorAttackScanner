package com.google.android.gms.common.api;

public abstract interface ResultCallback<R extends Result>
{
  public abstract void onResult(R paramR);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.ResultCallback
 * JD-Core Version:    0.6.0
 */
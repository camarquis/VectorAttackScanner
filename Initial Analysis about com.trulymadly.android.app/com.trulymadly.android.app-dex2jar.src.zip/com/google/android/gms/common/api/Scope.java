package com.google.android.gms.common.api;

public final class Scope
{
  private final String zP;

  public Scope(String paramString)
  {
    this.zP = paramString;
  }

  public String dD()
  {
    return this.zP;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.Scope
 * JD-Core Version:    0.6.0
 */
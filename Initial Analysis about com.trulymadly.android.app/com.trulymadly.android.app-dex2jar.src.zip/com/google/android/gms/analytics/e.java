package com.google.android.gms.analytics;

abstract interface e
{
  public abstract void p(boolean paramBoolean);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.e
 * JD-Core Version:    0.6.0
 */
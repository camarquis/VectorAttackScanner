package com.google.android.gms.analytics;

import com.google.android.gms.internal.di;
import java.util.List;
import java.util.Map;

abstract interface ag
{
  public abstract void b(Map<String, String> paramMap, long paramLong, String paramString, List<di> paramList);

  public abstract void bI();

  public abstract void bk();

  public abstract void bp();

  public abstract void br();
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.ag
 * JD-Core Version:    0.6.0
 */
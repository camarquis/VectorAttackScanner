package com.google.android.gms.analytics;

abstract class af
{
  abstract void bF();

  abstract void dispatchLocalHits();

  abstract void q(boolean paramBoolean);

  abstract void setLocalDispatchPeriod(int paramInt);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.af
 * JD-Core Version:    0.6.0
 */
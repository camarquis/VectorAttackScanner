package com.google.android.gms.analytics;

import java.util.Map;

abstract class TrackerHandler
{
  abstract void n(Map<String, String> paramMap);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.TrackerHandler
 * JD-Core Version:    0.6.0
 */
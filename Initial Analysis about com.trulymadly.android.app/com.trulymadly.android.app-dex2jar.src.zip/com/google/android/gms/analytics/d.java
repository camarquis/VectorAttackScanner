package com.google.android.gms.analytics;

import com.google.android.gms.internal.di;
import java.util.Collection;
import java.util.Map;

abstract interface d
{
  public abstract void a(Map<String, String> paramMap, long paramLong, String paramString, Collection<di> paramCollection);

  public abstract void bp();

  public abstract n bq();

  public abstract void i(long paramLong);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.d
 * JD-Core Version:    0.6.0
 */
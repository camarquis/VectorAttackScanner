package com.google.android.gms.analytics;

import java.util.List;

abstract interface n
{
  public abstract void A(String paramString);

  public abstract int a(List<x> paramList, ab paramab, boolean paramBoolean);

  public abstract boolean bA();
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.n
 * JD-Core Version:    0.6.0
 */
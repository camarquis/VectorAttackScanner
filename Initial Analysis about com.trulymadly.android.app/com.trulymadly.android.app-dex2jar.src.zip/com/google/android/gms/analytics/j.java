package com.google.android.gms.analytics;

abstract interface j
{
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.j
 * JD-Core Version:    0.6.0
 */
package com.google.android.gms.analytics;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

abstract interface f
{
  public abstract void bk();

  public abstract void bp();

  public abstract void br();

  public abstract LinkedBlockingQueue<Runnable> bs();

  public abstract Thread getThread();

  public abstract void n(Map<String, String> paramMap);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.f
 * JD-Core Version:    0.6.0
 */
package com.google.android.gms.analytics;

abstract interface ad
{
  public abstract boolean cl();
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.ad
 * JD-Core Version:    0.6.0
 */
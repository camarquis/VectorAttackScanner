package com.google.android.gms.ads.doubleclick;

public abstract interface AppEventListener
{
  public abstract void onAppEvent(String paramString1, String paramString2);
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.doubleclick.AppEventListener
 * JD-Core Version:    0.6.0
 */
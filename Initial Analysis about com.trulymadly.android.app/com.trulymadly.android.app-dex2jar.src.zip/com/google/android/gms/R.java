package com.google.android.gms;

public final class R
{
  public static final class attr
  {
    public static final int adSize = 2130772092;
    public static final int adSizes = 2130772093;
    public static final int adUnitId = 2130772094;
    public static final int cameraBearing = 2130772096;
    public static final int cameraTargetLat = 2130772097;
    public static final int cameraTargetLng = 2130772098;
    public static final int cameraTilt = 2130772099;
    public static final int cameraZoom = 2130772100;
    public static final int mapType = 2130772095;
    public static final int uiCompass = 2130772101;
    public static final int uiRotateGestures = 2130772102;
    public static final int uiScrollGestures = 2130772103;
    public static final int uiTiltGestures = 2130772104;
    public static final int uiZoomControls = 2130772105;
    public static final int uiZoomGestures = 2130772106;
    public static final int useViewLifecycle = 2130772107;
    public static final int zOrderOnTop = 2130772108;
  }

  public static final class color
  {
    public static final int common_action_bar_splitter = 2131165196;
    public static final int common_signin_btn_dark_text_default = 2131165187;
    public static final int common_signin_btn_dark_text_disabled = 2131165189;
    public static final int common_signin_btn_dark_text_focused = 2131165190;
    public static final int common_signin_btn_dark_text_pressed = 2131165188;
    public static final int common_signin_btn_default_background = 2131165195;
    public static final int common_signin_btn_light_text_default = 2131165191;
    public static final int common_signin_btn_light_text_disabled = 2131165193;
    public static final int common_signin_btn_light_text_focused = 2131165194;
    public static final int common_signin_btn_light_text_pressed = 2131165192;
    public static final int common_signin_btn_text_dark = 2131165260;
    public static final int common_signin_btn_text_light = 2131165261;
  }

  public static final class drawable
  {
    public static final int common_signin_btn_icon_dark = 2130837652;
    public static final int common_signin_btn_icon_disabled_dark = 2130837653;
    public static final int common_signin_btn_icon_disabled_focus_dark = 2130837654;
    public static final int common_signin_btn_icon_disabled_focus_light = 2130837655;
    public static final int common_signin_btn_icon_disabled_light = 2130837656;
    public static final int common_signin_btn_icon_focus_dark = 2130837657;
    public static final int common_signin_btn_icon_focus_light = 2130837658;
    public static final int common_signin_btn_icon_light = 2130837659;
    public static final int common_signin_btn_icon_normal_dark = 2130837660;
    public static final int common_signin_btn_icon_normal_light = 2130837661;
    public static final int common_signin_btn_icon_pressed_dark = 2130837662;
    public static final int common_signin_btn_icon_pressed_light = 2130837663;
    public static final int common_signin_btn_text_dark = 2130837664;
    public static final int common_signin_btn_text_disabled_dark = 2130837665;
    public static final int common_signin_btn_text_disabled_focus_dark = 2130837666;
    public static final int common_signin_btn_text_disabled_focus_light = 2130837667;
    public static final int common_signin_btn_text_disabled_light = 2130837668;
    public static final int common_signin_btn_text_focus_dark = 2130837669;
    public static final int common_signin_btn_text_focus_light = 2130837670;
    public static final int common_signin_btn_text_light = 2130837671;
    public static final int common_signin_btn_text_normal_dark = 2130837672;
    public static final int common_signin_btn_text_normal_light = 2130837673;
    public static final int common_signin_btn_text_pressed_dark = 2130837674;
    public static final int common_signin_btn_text_pressed_light = 2130837675;
    public static final int ic_plusone_medium_off_client = 2130837725;
    public static final int ic_plusone_small_off_client = 2130837726;
    public static final int ic_plusone_standard_off_client = 2130837727;
    public static final int ic_plusone_tall_off_client = 2130837728;
  }

  public static final class id
  {
    public static final int hybrid = 2131361823;
    public static final int none = 2131361818;
    public static final int normal = 2131361800;
    public static final int satellite = 2131361824;
    public static final int terrain = 2131361825;
  }

  public static final class integer
  {
    public static final int google_play_services_version = 2131296257;
  }

  public static final class string
  {
    public static final int auth_client_needs_enabling_title = 2131427362;
    public static final int auth_client_needs_installation_title = 2131427363;
    public static final int auth_client_needs_update_title = 2131427364;
    public static final int auth_client_play_services_err_notification_msg = 2131427365;
    public static final int auth_client_requested_by_msg = 2131427366;
    public static final int auth_client_using_bad_version_title = 2131427361;
    public static final int common_google_play_services_enable_button = 2131427347;
    public static final int common_google_play_services_enable_text = 2131427346;
    public static final int common_google_play_services_enable_title = 2131427345;
    public static final int common_google_play_services_install_button = 2131427344;
    public static final int common_google_play_services_install_text_phone = 2131427342;
    public static final int common_google_play_services_install_text_tablet = 2131427343;
    public static final int common_google_play_services_install_title = 2131427341;
    public static final int common_google_play_services_invalid_account_text = 2131427353;
    public static final int common_google_play_services_invalid_account_title = 2131427352;
    public static final int common_google_play_services_network_error_text = 2131427351;
    public static final int common_google_play_services_network_error_title = 2131427350;
    public static final int common_google_play_services_unknown_issue = 2131427354;
    public static final int common_google_play_services_unsupported_date_text = 2131427357;
    public static final int common_google_play_services_unsupported_text = 2131427356;
    public static final int common_google_play_services_unsupported_title = 2131427355;
    public static final int common_google_play_services_update_button = 2131427358;
    public static final int common_google_play_services_update_text = 2131427349;
    public static final int common_google_play_services_update_title = 2131427348;
    public static final int common_signin_button_text = 2131427359;
    public static final int common_signin_button_text_long = 2131427360;
    public static final int location_client_powered_by_google = 2131427367;
  }

  public static final class styleable
  {
    public static final int[] AdsAttrs = { 2130772092, 2130772093, 2130772094 };
    public static final int AdsAttrs_adSize = 0;
    public static final int AdsAttrs_adSizes = 1;
    public static final int AdsAttrs_adUnitId = 2;
    public static final int[] MapAttrs = { 2130772095, 2130772096, 2130772097, 2130772098, 2130772099, 2130772100, 2130772101, 2130772102, 2130772103, 2130772104, 2130772105, 2130772106, 2130772107, 2130772108 };
    public static final int MapAttrs_cameraBearing = 1;
    public static final int MapAttrs_cameraTargetLat = 2;
    public static final int MapAttrs_cameraTargetLng = 3;
    public static final int MapAttrs_cameraTilt = 4;
    public static final int MapAttrs_cameraZoom = 5;
    public static final int MapAttrs_mapType = 0;
    public static final int MapAttrs_uiCompass = 6;
    public static final int MapAttrs_uiRotateGestures = 7;
    public static final int MapAttrs_uiScrollGestures = 8;
    public static final int MapAttrs_uiTiltGestures = 9;
    public static final int MapAttrs_uiZoomControls = 10;
    public static final int MapAttrs_uiZoomGestures = 11;
    public static final int MapAttrs_useViewLifecycle = 12;
    public static final int MapAttrs_zOrderOnTop = 13;
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     com.google.android.gms.R
 * JD-Core Version:    0.6.0
 */
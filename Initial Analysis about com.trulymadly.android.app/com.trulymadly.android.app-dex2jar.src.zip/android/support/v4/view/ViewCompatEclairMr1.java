package android.support.v4.view;

import android.view.View;

class ViewCompatEclairMr1
{
  public static boolean isOpaque(View paramView)
  {
    return paramView.isOpaque();
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewCompatEclairMr1
 * JD-Core Version:    0.6.0
 */
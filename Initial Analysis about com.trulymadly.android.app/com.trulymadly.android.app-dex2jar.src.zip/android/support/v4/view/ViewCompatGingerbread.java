package android.support.v4.view;

import android.view.View;

class ViewCompatGingerbread
{
  public static int getOverScrollMode(View paramView)
  {
    return paramView.getOverScrollMode();
  }

  public static void setOverScrollMode(View paramView, int paramInt)
  {
    paramView.setOverScrollMode(paramInt);
  }
}

/* Location:           D:\disambler\package com.trulymadly.android.app\com.trulymadly.android.app-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewCompatGingerbread
 * JD-Core Version:    0.6.0
 */